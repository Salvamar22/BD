--****************************************************
-- Bases de datos: Introducci�n a SQL II
-- Autor: Erick Varela
-- Correspondencia: evarela@uca.edu.sv
-- Version: 1.0
--****************************************************

-- 1.0 Creando base de datos y seleccionandola para realizar consultas 
CREATE DATABASE Clase12Seccion01;
USE Clase12Seccion01; 
SET LANGUAGE us_english

-- 2.0 Creando base de datos
-- 2.1 Creando tablas
CREATE TABLE HOTEL (
	id INT PRIMARY KEY IDENTITY,
	nombre VARCHAR(50) NOT NULL,
	direccion VARCHAR(50) NULL DEFAULT 'Direcci�n no definida', 
	telefono CHAR(12) NOT NULL UNIQUE CHECK (telefono LIKE '+503[2|6|7][0-9][0-9][0-9][0-9][0-9][0-9][0-9]')
);

CREATE TABLE HABITACION(
	id INT PRIMARY KEY IDENTITY,
	numero INT NOT NULL CHECK (numero > 0),
	precio MONEY NOT NULL,
	id_hotel INT NOT NULL
);

CREATE TABLE CLIENTE(
	id INT PRIMARY KEY IDENTITY,
	nombre VARCHAR(50) NOT NULL,
	correo VARCHAR(50) NOT NULL UNIQUE 
);

CREATE TABLE RESERVA (
	id INT PRIMARY KEY IDENTITY,
	id_cliente INT NOT NULL,
	id_habitacion INT NOT NULL,
	checkin DATE NOT NULL, 
	checkout DATE NOT NULL
)


-- 2.1 Creando llaves for�neas
-- FK hotel -> habitacion
ALTER TABLE HABITACION ADD CONSTRAINT FK_hotel_habitacion 
	FOREIGN KEY (id_hotel) REFERENCES HOTEL (id);
-- FK usuario -> reserva
ALTER TABLE RESERVA ADD CONSTRAINT FK_usuario_reserva
	FOREIGN KEY (id_cliente) REFERENCES CLIENTE (id);
-- FK habitacion -> reserva
ALTER TABLE RESERVA ADD CONSTRAINT FK_habitacion_reserva
	FOREIGN KEY (id_habitacion) REFERENCES HABITACION (id);

-- 2.2 Crear el diagrama para verificar que la base de datos se haya creado correctamente 

-- 2.3 Insertar datos a las tablas
INSERT INTO HOTEL (nombre, direccion, telefono) VALUES ('Real Intercontinental', 'San Salvador', '+50324234992');
INSERT INTO HOTEL (nombre, direccion, telefono) VALUES ('Crowne Plaza', NULL,'+50375008446');
INSERT INTO HOTEL (nombre, telefono) VALUES ('Quality Hotel Real Aeropuerto', '+50325008440'); 

INSERT INTO HABITACION (numero, precio, id_hotel) VALUES(100, 200.50,1);
INSERT INTO HABITACION (numero, precio, id_hotel) VALUES(101, 153.78,1);
INSERT INTO HABITACION (numero, precio, id_hotel) VALUES(10, 120.32,2);
INSERT INTO HABITACION (numero, precio, id_hotel) VALUES(11, 150.00, 2);
INSERT INTO HABITACION (numero, precio, id_hotel) VALUES(100, 150.00,3);

INSERT INTO CLIENTE VALUES('Kaseem Sears','PFQHXJ@maiq.rom');
INSERT INTO CLIENTE VALUES('Susan','ILDGCQ@maio.com');
INSERT INTO CLIENTE VALUES('Amena','PBHPRB@maia.fom');
INSERT INTO CLIENTE VALUES('Natalie','XUQZUC@maii.com');
INSERT INTO CLIENTE VALUES('Evelyn','RBGXGX@maih.ru');

INSERT INTO RESERVA (id_cliente, id_habitacion, checkin, checkout) VALUES (5,3,'2021-01-03','2021-01-05');
INSERT INTO RESERVA (id_cliente, id_habitacion, checkin, checkout) VALUES (2,3,'2021-01-10','2021-01-13');
INSERT INTO RESERVA (id_cliente, id_habitacion, checkin, checkout) VALUES (4,1,'2021-01-03','2021-01-04');
INSERT INTO RESERVA (id_cliente, id_habitacion, checkin, checkout) VALUES (2,5,'2021-01-16','2021-01-17');
INSERT INTO RESERVA (id_cliente, id_habitacion, checkin, checkout) VALUES (2,5,'2021-01-15','2021-01-18');
INSERT INTO RESERVA (id_cliente, id_habitacion, checkin, checkout) VALUES (2,2,'2021-01-10','2021-01-12');
INSERT INTO RESERVA (id_cliente, id_habitacion, checkin, checkout) VALUES (3,2,'2021-01-22','2021-01-23');
INSERT INTO RESERVA (id_cliente, id_habitacion, checkin, checkout) VALUES (1,2,'2021-01-02','2021-01-16');
INSERT INTO RESERVA (id_cliente, id_habitacion, checkin, checkout) VALUES (5,3,'2021-01-24','2021-01-25');
INSERT INTO RESERVA (id_cliente, id_habitacion, checkin, checkout) VALUES (5,3,'2021-01-29','2021-01-30');
INSERT INTO RESERVA (id_cliente, id_habitacion, checkin, checkout) VALUES (2,3,'2021-01-15','2021-01-25');
INSERT INTO RESERVA (id_cliente, id_habitacion, checkin, checkout) VALUES (4,3,'2021-01-14','2021-01-16');
INSERT INTO RESERVA (id_cliente, id_habitacion, checkin, checkout) VALUES (2,5,'2021-01-04','2021-01-20');
INSERT INTO RESERVA (id_cliente, id_habitacion, checkin, checkout) VALUES (4,1,'2021-01-11','2021-01-17');
INSERT INTO RESERVA (id_cliente, id_habitacion, checkin, checkout) VALUES (4,3,'2021-01-13','2021-01-20');

SELECT * FROM RESERVA;

-- 3.0 Sentencia DELETE
-- 3.1 Borrar todos los datos de reserva:
DELETE FROM RESERVA;
SELECT * FROM RESERVA;
-- 3.2 Insertar todos los datos de reserva y borrar la �ltima reserva
SELECT * FROM RESERVA;
-- en la clase el �ltimo id era 49
DELETE FROM RESERVA WHERE id = 49;
SELECT * FROM RESERVA;

-- 4.0 Sentencia UPDATE
-- 4.1 Actualizar el nombre del cliente "Natalie" a "Natalie Volkova"
SELECT * FROM CLIENTE;
UPDATE CLIENTE SET nombre = 'Natalie Volkova'
-- Re escribimos todos los nombre, recuperando (de manera muy desesperada e inadecuada los datos)
DELETE FROM RESERVA;
DELETE FROM CLIENTE;
-- insertar clientes y reservas de nuevo
SELECT * FROM CLIENTE;

-- �Que pasa si olvidamos el WHERE? F
-- nota: cuando hicimos el ejercicio en clase "natalie" tenia el id 9
UPDATE CLIENTE SET nombre = 'Natalie Volkova' WHERE id = 15;
SELECT * FROM CLIENTE;

-- 5.0 Sentencia SELECT
-- 5.1 Mostrando todas las habitaciones registradas en la base de datos
SELECT id, numero, precio, id_hotel FROM HABITACION;

-- 5.1.1 Formato select general
SELECT * FROM HABITACION;
