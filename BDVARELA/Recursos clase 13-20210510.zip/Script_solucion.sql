--****************************************************
-- Bases de datos: 13 Consulta de datos b�sica
-- Autor: Erick Varela
-- Correspondencia: evarela@uca.edu.sv
-- Version: 1.0
--****************************************************
USE HotelManagementDB;
SET LANGUAGE us_english
--**********************************************************************
-- 1.0 Condiciones l�gicas
-- 1.1 Mostrar todas las reservas con id mayor a 90
SELECT id, checkin, checkout, id_cliente, id_habitacion
FROM RESERVA
WHERE id > 90;

-- 1.2 Mostrar todas las reservas con id menor o igual a 10
SELECT id, checkin, checkout, id_cliente, id_habitacion
FROM RESERVA
WHERE id <= 10;

-- 1.3 Mostrar todas las reservas con id entre 25 y 40
SELECT id, checkin, checkout, id_cliente, id_habitacion
FROM RESERVA
WHERE id >= 25 
	AND id <= 40;

-- 1.3.1 Instrucci�n BETWEEN: Mostrar todas las reservas con id entre 25 y 40
SELECT id, checkin, checkout, id_cliente, id_habitacion
FROM RESERVA
WHERE id BETWEEN 25 AND 40;

-- 1.3.1 Verificar el efecto en la consulta de NOT BETWEEN
SELECT id, checkin, checkout, id_cliente, id_habitacion
FROM RESERVA
WHERE id NOT BETWEEN 25 AND 40;

-- 1.4 Instrucci�n  OR: Mostrar las reservas con id menores a 10 o mayores a 90
SELECT id, checkin, checkout, id_cliente, id_habitacion
FROM RESERVA
WHERE id < 10 
	OR id > 90;

-- 1.4.1 Instrucci�n  OR: Mostrar las reservas con id entre 10 y 90.
SELECT id, checkin, checkout, id_cliente, id_habitacion
FROM RESERVA
WHERE id <= 10 
	OR id >= 90;

-- 1.4 Instrucci�n  OR: Mostrar las reservas con id menores a 10, id mayores a 90 y menores a 100
SELECT id, checkin, checkout, id_cliente, id_habitacion
FROM RESERVA
WHERE (id < 10 OR id > 90) 
	AND id < 100;

-- 1.5 Instrucci�n AND: Mostrar las reservas realizadas durante enero de 2010
SELECT id, checkin, checkout, id_cliente, id_habitacion
FROM RESERVA
WHERE checkin >= '2010-01-01' AND checkin <= '2010-01-31';  

-- 1.5.1 Mostrar las reservas que sean mayores a 4 d�as
SELECT id, checkin, checkout, id_cliente, id_habitacion
FROM RESERVA
WHERE DATEDIFF (DAY,checkin,checkout) > 4;

-- 1.6 Mostrar los clientes con correo que finalicen en .pom
SELECT * 
FROM CLIENTE
WHERE correo LIKE '%.pom';

-- 1.6.1 Mostrar los clientes con correo que no finalicen en .pom
SELECT * 
FROM CLIENTE
WHERE correo NOT LIKE '%.pom';

-- 1.6.2 Mostrar los clientes cuyo correo contenga una x antes del @
SELECT * 
FROM CLIENTE
WHERE correo LIKE '%[xX]%@%';

--**********************************************************************
-- 2.0 Consultas basicas
-- 2.1 Mostrar cada el id y nombre de cada hotel y a que categor�a pertenece:
SELECT id, nombre, id_categoria
FROM HOTEL;

-- 2.2 Mostrar cada el id y nombre de cada hotel y el nombre de la categor�a a la que pertenece:
SELECT HOTEL.id AS 'id hotel', HOTEL.nombre AS 'nombre hotel', CATEGORIA.categoria
FROM HOTEL, CATEGORIA
WHERE HOTEL.id_categoria = CATEGORIA.id;

-- 2.3 Mostrar toda la informaci�n de cada cliente excepto el correo electr�nico:
SELECT CLIENTE.id, CLIENTE.nombre, CLIENTE.id_pais, CLIENTE.tipo_cliente
FROM CLIENTE;

-- 2.4 Mostrar toda la informaci�n de cada cliente excepto el correo electr�nico, 
--mostrando el nombre del pais al cual pertenece y el tipo de cliente que es:
SELECT CLIENTE.id, CLIENTE.nombre, PAIS.pais, TIPO_CLIENTE.tipo
FROM PAIS, CLIENTE, TIPO_CLIENTE
WHERE CLIENTE.id_pais = PAIS.id
	AND CLIENTE.tipo_cliente =	TIPO_CLIENTE.id;
	
-- 2.5 Mostrar toda la informaci�n de cada cliente excepto el correo electr�nico, 
--que sean tipo "Viajero", se debe mostrar el nombre del pais al cual pertenece 
--y el tipo de cliente que es:
SELECT CLIENTE.id, CLIENTE.nombre, PAIS.pais, TIPO_CLIENTE.tipo
FROM PAIS, CLIENTE, TIPO_CLIENTE
WHERE CLIENTE.id_pais = PAIS.id
	AND CLIENTE.tipo_cliente =	TIPO_CLIENTE.id
	AND TIPO_CLIENTE.tipo = 'Viajero';
	
-- 2.6 Mostrar toda la informaci�n de cada cliente, que provengan de centroam�rica. 
--Se debe mostrar el nombre del pais al cual pertenece y el tipo de cliente que es:
SELECT CLIENTE.id, CLIENTE.nombre, PAIS.pais, TIPO_CLIENTE.tipo
FROM PAIS, CLIENTE, TIPO_CLIENTE
WHERE CLIENTE.id_pais = PAIS.id
	AND CLIENTE.tipo_cliente =	TIPO_CLIENTE.id
	AND (
		PAIS.pais = 'El Salvador' OR
		PAIS.pais = 'Honduras' OR
		PAIS.pais = 'Guatemala' OR  
		PAIS.pais = 'Nicaragua' OR
		PAIS.pais = 'Panama' OR
		PAIS.pais = 'Costa Rica' OR  
		PAIS.pais = 'Belice'
	);

