--****************************************************
-- Bases de datos: 14 Joins
-- Autor: Erick Varela
-- Correspondencia: evarela@uca.edu.sv
-- Version: 1.0
--****************************************************
USE HotelManagementDB;
SET LANGUAGE us_english
--*****************************************************

-- *****************************************************
-- 1.	ORDER BY
-- *****************************************************
-- 1.1	Mostrar los datos de la tabla reserva. 
--		Ordenar los datos a partir del id de cliente en orden descendente
SELECT R.id, R.checkin, R.checkout, R.id_cliente, R.id_habitacion
FROM RESERVA R
ORDER BY R.id_cliente DESC;

-- 1.2	Mostrar los datos de la tabla RESERVA. Incluir el nombre del cliente, 
--		el hotel y el n�mero de habitaci�n reservada.
--		Ordenar la tabla con respecto al nombre del cliente en forma ascendente.
SELECT R.id, R.checkin, R.checkout, HO.nombre 'Hotel', H.numero 'Habitacion', C.nombre 'Cliente'
FROM RESERVA R, CLIENTE C, HABITACION H, HOTEL HO
WHERE C.id = R.id_cliente 
	AND H.id = R.id_habitacion
	AND HO.id = H.id_hotel
ORDER BY C.nombre ASC;

-- 1.2.1 Cada cliente ha realizado 1 o varias RESERVAs, ordenar la lista segun
--		 el nombre del cliente (orden ascendente) y por cada cliente ordenar sus RESERVAS
--		 de manera cronologica.
SELECT R.id, R.checkin, R.checkout, HO.nombre 'Hotel', H.numero 'Habitacion', C.nombre 'Cliente'
FROM RESERVA R, CLIENTE C, HABITACION H, HOTEL HO
WHERE C.id = R.id_cliente 
	AND H.id = R.id_habitacion
	AND HO.id = H.id_hotel
ORDER BY C.nombre ASC, R.checkin ASC;

-- 1.2.2 Mostrar los datos de la tabla RESERVA. Incluir el nombre del cliente, 
--		 el hotel y el n�mero de habitaci�n reservada.
--		 Ordenar la tabla con respecto al nombre del cliente en forma ascendente.
--		 Como segundo y tercer criterio de orden utilizar el hotel y el n�mero de habitaci�n
SELECT R.id, R.checkin, R.checkout, HO.nombre 'Hotel', H.numero 'Habitacion', C.nombre 'Cliente'
FROM RESERVA R, CLIENTE C, HABITACION H, HOTEL HO
WHERE C.id = R.id_cliente 
	AND H.id = R.id_habitacion
	AND HO.id = H.id_hotel
ORDER BY C.nombre ASC, HO.nombre ASC, H.numero ASC;

-- *****************************************************
-- 2.0	GROUP BY
-- *****************************************************
-- 2.1	�cuantos clientes hay por cada pais? Ordenar la lista en orden descendente
SELECT P.pais, COUNT(C.nombre) 'cantidad de clientes'
FROM PAIS P, CLIENTE C
WHERE P.id = C.id_pais
GROUP BY P.pais
ORDER BY COUNT(C.nombre) DESC;

-- 2.1.1 �cuantos clientes hay por cada pais? Ordenar la lista en orden descendente
--		 Incluir el id y nombre de cada pais.
SELECT P.id, P.pais, COUNT(C.nombre) 'cantidad de clientes'
FROM PAIS P, CLIENTE C
WHERE P.id = C.id_pais
GROUP BY P.id, P.pais
ORDER BY COUNT(C.nombre) DESC;

-- 2.2	mostrar los paises con ningun cliente
SELECT P.id, P.pais, C.id, C.nombre
FROM PAIS P 
	LEFT JOIN CLIENTE C
ON P.id = C.id_pais
WHERE C.id IS NULL;

-- 2.3 �Cuantas RESERVAs se han realizado en cada hotel?
SELECT HO.id, HO.nombre, COUNT(R.checkin) 'Cantidad de reservas'
FROM HOTEL HO, RESERVA R, HABITACION H
WHERE HO.id = H.id_hotel
	AND H.id = R.id_habitacion
GROUP BY HO.id, HO.nombre
ORDER BY HO.id ASC;

-- 2.4 �Cual es la habitaci�n m�s barata y m�s cara de cada hotel?
SELECT HO.nombre, MIN(H.precio) 'Mas barato', MAX(H.precio) 'Mas caro'
FROM HOTEL HO, HABITACION H
WHERE HO.id = H.id_hotel
GROUP BY HO.nombre
ORDER BY HO.nombre ASC;

-- 2.4.1 �Cual es la habitaci�n m�s barata y m�s cara de cada hotel?
--		 Incluir el n�mero de habitaci�n.
/*
NOTA: Esta consulta no es posible realizarla con las herramientas
vistas hasta ahora, se necesitan SUB CONSULTAS.
*/

--2.5	Mostrar el detalle de cada RESERVA con respecto a los precios.
--		La consulta final debe mostrar el id de la reserva, fechas de checkin y checkout,
--		el nombre del cliente que ha reservado, el precio de la habitacion y el total de los servicios extra.

-- paso 1. mostrando las reservas y definiendo al correspondencia con la tabla extras
SELECT R.id, R.checkin, R.checkout, X.id_servicio 'id servicio extra solicitado'
FROM RESERVA R 
	LEFT JOIN EXTRAS X
ON R.id = X.id_reserva;

-- Paso 2. obteniendo el precio del servicio extra
SELECT R.id, R.checkin, R.checkout, X.id_servicio 'id servicio extra solicitado', S.nombre, S.precio
FROM RESERVA R 
	LEFT JOIN EXTRAS X
ON R.id = X.id_reserva
	LEFT JOIN SERVICIO S
ON S.id = X.id_servicio;

-- Paso 2.1. quitando columnas que no necesitamos
SELECT R.id, R.checkin, R.checkout, S.precio 'precio servicio'
FROM RESERVA R 
	LEFT JOIN EXTRAS X
ON R.id = X.id_reserva
	LEFT JOIN SERVICIO S
ON S.id = X.id_servicio;

-- Paso 3. Incluyendo el nombre del cliente, y el precio de la habitaci�n
SELECT R.id, R.checkin, R.checkout, C.nombre,H.precio 'precio habitacion',S.precio 'precio servicio'
FROM RESERVA R 
	LEFT JOIN EXTRAS X
ON R.id = X.id_reserva
	LEFT JOIN SERVICIO S
ON S.id = X.id_servicio
	LEFT JOIN CLIENTE C
ON C.id = R.id_cliente
	LEFT JOIN HABITACION H
ON H.id = R.id_habitacion;

-- Paso 4. cambiando los nulos por el valor '0.00'
SELECT R.id, R.checkin, R.checkout, C.nombre,H.precio 'precio habitacion',ISNULL(S.precio,0.00) 'precio servicio'
FROM RESERVA R 
	LEFT JOIN EXTRAS X
ON R.id = X.id_reserva
	LEFT JOIN SERVICIO S
ON S.id = X.id_servicio
	LEFT JOIN CLIENTE C
ON C.id = R.id_cliente
	LEFT JOIN HABITACION H
ON H.id = R.id_habitacion;

-- paso 5. Sumando los precios de los servicios extra
SELECT R.id, R.checkin, R.checkout, C.nombre,H.precio 'precio habitacion',SUM(ISNULL(S.precio,0.00)) 'precio servicio'
FROM RESERVA R 
	LEFT JOIN EXTRAS X
ON R.id = X.id_reserva
	LEFT JOIN SERVICIO S
ON S.id = X.id_servicio
	LEFT JOIN CLIENTE C
ON C.id = R.id_cliente
	LEFT JOIN HABITACION H
ON H.id = R.id_habitacion
GROUP BY R.id, R.checkin, R.checkout, C.nombre,H.precio
ORDER BY R.id ASC;

-- OFF TOPIC 
SELECT R.id, R.checkin, R.checkout, C.nombre, H.precio*DATEDIFF (DAY, R.checkin, R.checkout) 'total reserva habitaci�n', SUM(ISNULL(S.precio,0.00)) 'precio servicio', SUM(ISNULL(S.precio,0.00))+H.precio*DATEDIFF (DAY, R.checkin, R.checkout) 'TOTAL RESERVA'
FROM RESERVA R 
	LEFT JOIN EXTRAS X
ON R.id = X.id_reserva
	LEFT JOIN SERVICIO S
ON S.id = X.id_servicio
	LEFT JOIN CLIENTE C
ON C.id = R.id_cliente
	LEFT JOIN HABITACION H
ON H.id = R.id_habitacion
GROUP BY R.id, R.checkin, R.checkout, C.nombre,H.precio, H.precio*DATEDIFF (DAY, R.checkin, R.checkout)
ORDER BY R.id ASC;