--****************************************************
-- Bases de datos: instrucciones HAVING e INTO
-- Autor: Erick Varela
-- Correspondencia: evarela@uca.edu.sv
-- Version: 1.0
--****************************************************
USE HotelManagementDB;
SET LANGUAGE us_english
--*****************************************************

-- *****************************************************
-- 1.	instruccion HAVING
-- *****************************************************
-- 1.1  Mostrar las HABITACIONES que hayan sido RESERVADAS durante al menos 10 dias 
--		durante el primer semestre del a�o 2010.
-- paso 1: definiendo fuente de datos, y mostrando detalles de la reserva
SELECT R.id 'id reserva', R.checkin, R.checkout, H.id 'id habitacion', H.numero
FROM HABITACION H, RESERVA R
WHERE H.id = R.id_habitacion
	AND R.checkin BETWEEN '2010-01-01' AND '2010-06-30'
ORDER BY H.id;

/*
NOTA: considerando otro logica para el periodo de tiempo
SELECT R.id 'id reserva', R.checkin, R.checkout, H.id 'id habitacion', H.numero
FROM HABITACION H, RESERVA R
WHERE H.id = R.id_habitacion
	AND R.checkin >= '2010-07-01' 
	AND R.checkout <= '2010-12-31'
ORDER BY H.id;
*/

-- paso 2.1: definiendo dias de cada reserva, y removiendo columnas de poco interes
SELECT R.id 'id reserva', DATEDIFF(DAY,R.checkin, R.checkout) 'dias de reserva',H.id 'id habitacion', H.numero
FROM HABITACION H, RESERVA R
WHERE H.id = R.id_habitacion
	AND R.checkin BETWEEN '2010-01-01' AND '2010-06-30'
ORDER BY H.id;

-- paso 2.2: sumando dias de reserva con respecto a cada habitaci�n
SELECT SUM(DATEDIFF(DAY,R.checkin, R.checkout)) 'dias de reserva',H.id 'id habitacion', H.numero
FROM HABITACION H, RESERVA R
WHERE H.id = R.id_habitacion
	AND R.checkin BETWEEN '2010-01-01' AND '2010-06-30'
GROUP BY H.id, H.numero
ORDER BY H.id;

--paso 3: filtrando habitaciones con respecto a la cantidad de d�as reservadas 
SELECT SUM(DATEDIFF(DAY,R.checkin, R.checkout)) 'dias de reserva',H.id 'id habitacion', H.numero
FROM HABITACION H, RESERVA R
WHERE H.id = R.id_habitacion
	AND R.checkin BETWEEN '2010-01-01' AND '2010-06-30'
	AND SUM(DATEDIFF(DAY,R.checkin, R.checkout)) >= 10
GROUP BY H.id, H.numero
ORDER BY H.id; -- esta consulta falla
-- razon: no podemos hacer una comparaci�n que contenga una funci�n de agregaci�n en el WHERE

SELECT SUM(DATEDIFF(DAY,R.checkin, R.checkout)) 'dias de reserva',H.id 'id habitacion', H.numero
FROM HABITACION H, RESERVA R
WHERE H.id = R.id_habitacion
	AND R.checkin BETWEEN '2010-01-01' AND '2010-06-30'
GROUP BY H.id, H.numero
HAVING SUM(DATEDIFF(DAY,R.checkin, R.checkout)) >= 10
ORDER BY H.id;

-- 1.2  Mostrar la lista de clientes 'VIP'
--		Un cliente VIP se define si el promedio de todas 
--		las habitaciones reservadas es mayor a $1000
-- paso 1: mostrando datos generales de la reserva
SELECT R.id 'id reserva', R.checkin, R.checkout, C.id 'id cliente', C.nombre, H.precio 'precio de habitacion'
FROM HABITACION H, RESERVA R, CLIENTE C
WHERE H.id = R.id_habitacion
	AND C.id = R.id_cliente;

-- paso 2.1: obteniendo total de dias reservados y multiplicando por el precio de la habitacion
SELECT R.id 'id reserva', DATEDIFF(DAY, R.checkin, R.checkout) 'reserva en dias',C.id 'id cliente', C.nombre, H.precio 'precio de habitacion'
FROM HABITACION H, RESERVA R, CLIENTE C
WHERE H.id = R.id_habitacion
	AND C.id = R.id_cliente;

-- paso 2.2: multiplicando precio de habitacion con el numero de dias
--			 y ordenando con respecto al id de cliente
SELECT R.id 'id reserva', DATEDIFF(DAY, R.checkin, R.checkout)*H.precio 'total reserva',C.id 'id cliente', C.nombre
FROM HABITACION H, RESERVA R, CLIENTE C
WHERE H.id = R.id_habitacion
	AND C.id = R.id_cliente
ORDER BY C.id ASC;

-- paso 3: obteniendo promedio. NOTA: debemos eliminar campos que nos estorban (R.id en este caso).
-- SELECT (173.44+85.19)/2 = 129.315000
SELECT AVG(DATEDIFF(DAY, R.checkin, R.checkout)*H.precio) 'total reserva',C.id 'id cliente', C.nombre
FROM HABITACION H, RESERVA R, CLIENTE C
WHERE H.id = R.id_habitacion
	AND C.id = R.id_cliente
GROUP BY C.id, C.nombre
ORDER BY C.id ASC;

-- Paso 4: filtrando a los cliente VIP
SELECT AVG(DATEDIFF(DAY, R.checkin, R.checkout)*H.precio) 'total reserva',C.id 'id cliente', C.nombre
FROM HABITACION H, RESERVA R, CLIENTE C
WHERE H.id = R.id_habitacion
	AND C.id = R.id_cliente
	AND AVG(DATEDIFF(DAY, R.checkin, R.checkout)*H.precio)  > 1000
GROUP BY C.id, C.nombre
ORDER BY C.id ASC; -- esta instruccion falla.

SELECT AVG(DATEDIFF(DAY, R.checkin, R.checkout)*H.precio) 'total reserva',C.id 'id cliente', C.nombre
FROM HABITACION H, RESERVA R, CLIENTE C
WHERE H.id = R.id_habitacion
	AND C.id = R.id_cliente
GROUP BY C.id, C.nombre
HAVING AVG(DATEDIFF(DAY, R.checkin, R.checkout)*H.precio)  > 1000
ORDER BY C.id ASC; 

-- 1.3	Mostrar la categoria de habitacion del hotel Semper, 
--		que genero mas de $700 en el primer trimestre de 2010
SELECT SUM(DATEDIFF(DAY, R.checkin, R.checkout)* H.precio) 'total reserva', TH.nombre 'tipo habitacion'
FROM HOTEL HO, HABITACION H, TIPO_HABITACION TH, RESERVA R
WHERE HO.id = H.id_hotel
	AND TH.id = H.id_tipo
	AND H.id = R.id_habitacion
	AND HO.nombre = 'Semper'
GROUP BY TH.nombre
ORDER BY TH.nombre ASC;

SELECT SUM(DATEDIFF(DAY, R.checkin, R.checkout)* H.precio) 'total reserva', TH.nombre 'tipo habitacion'
FROM HOTEL HO, HABITACION H, TIPO_HABITACION TH, RESERVA R
WHERE HO.id = H.id_hotel
	AND TH.id = H.id_tipo
	AND H.id = R.id_habitacion
	AND HO.nombre = 'Semper'
GROUP BY TH.nombre
HAVING SUM(DATEDIFF(DAY, R.checkin, R.checkout)* H.precio) > 700
ORDER BY TH.nombre ASC;


-- *****************************************************
-- 2.	instruccion INTO
-- *****************************************************
-- 2.1	A partir del ejercicio extra visto en la clase 15:
SELECT R.id, R.checkin, R.checkout, C.nombre, H.precio*DATEDIFF (DAY, R.checkin, R.checkout) 'total reserva habitaci�n', SUM(ISNULL(S.precio,0.00)) 'precio servicio', SUM(ISNULL(S.precio,0.00))+H.precio*DATEDIFF (DAY, R.checkin, R.checkout) 'TOTAL RESERVA'
FROM RESERVA R 
	LEFT JOIN EXTRAS X
ON R.id = X.id_reserva
	LEFT JOIN SERVICIO S
ON S.id = X.id_servicio
	LEFT JOIN CLIENTE C
ON C.id = R.id_cliente
	LEFT JOIN HABITACION H
ON H.id = R.id_habitacion
GROUP BY R.id, R.checkin, R.checkout, C.nombre,H.precio, H.precio*DATEDIFF (DAY, R.checkin, R.checkout)
ORDER BY R.id ASC;

-- Utilizar la instrucci�n INTO para analizar su utilidad
SELECT R.id, R.checkin, R.checkout, C.nombre, H.precio*DATEDIFF (DAY, R.checkin, R.checkout) 'total reserva habitaci�n', SUM(ISNULL(S.precio,0.00)) 'precio servicio', SUM(ISNULL(S.precio,0.00))+H.precio*DATEDIFF (DAY, R.checkin, R.checkout) 'TOTAL RESERVA'
INTO reserva_total_seccion_01
FROM RESERVA R 
	LEFT JOIN EXTRAS X
ON R.id = X.id_reserva
	LEFT JOIN SERVICIO S
ON S.id = X.id_servicio
	LEFT JOIN CLIENTE C
ON C.id = R.id_cliente
	LEFT JOIN HABITACION H
ON H.id = R.id_habitacion
GROUP BY R.id, R.checkin, R.checkout, C.nombre,H.precio, H.precio*DATEDIFF (DAY, R.checkin, R.checkout)

SELECT * FROM reserva_total_seccion_01;
-- 2.2	Volver a ejecutar la consulta anterior y verificar el resultado.
-- 2.3	visualizar el diagrama relacional generado por SQL Server 
-- 2.4	Borrar todas las reservas, �que sucede con la tabla TOTAL_RESERVA?

DELETE FROM EXTRAS;
DELETE FROM RESERVA;
SELECT * FROM RESERVA;
SELECT * FROM reserva_total_seccion_01;

UPDATE reserva_total_seccion_01 SET nombre = 'Susan ABC' WHERE nombre = 'Susan �';

DROP TABLE reserva_total_seccion_01;
