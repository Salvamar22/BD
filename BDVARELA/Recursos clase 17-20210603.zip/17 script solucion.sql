--****************************************************
-- Bases de datos: Sub consultas
-- Autor: Erick Varela
-- Correspondencia: evarela@uca.edu.sv
-- Version: 1.0
--****************************************************
USE HotelManagementDB;
SET LANGUAGE us_english
--*****************************************************

-- *****************************************************
-- 1.	Subconsultas
-- *****************************************************

-- 1.1	�Cual es el porcentaje de clientes que vienen de cada pais?
--		incluir los paises sin ningun cliente asignado.
-- paso 1: calculando cantidad de clientes por pais.
SELECT P.id, P.pais, COUNT(C.nombre) 'cantidad de clientes'
FROM PAIS P 
	LEFT JOIN CLIENTE C
ON P.id = C.id_pais
GROUP BY P.id, P.pais
ORDER BY COUNT(C.nombre) DESC;

-- Paso 2: comprobando cantidad de clientes disponibles en la base de datos.
SELECT COUNT(*) FROM CLIENTE;

-- paso 3: calculando porcentaje
SELECT P.id, P.pais, CAST(COUNT(C.nombre) AS FLOAT)/25 * 100 'porcentaje de clientes'
FROM PAIS P 
	LEFT JOIN CLIENTE C
ON P.id = C.id_pais
GROUP BY P.id, P.pais
ORDER BY COUNT(C.nombre) DESC;

-- paso 4: obteniendo resultado de forma din�mica
SELECT P.id, P.pais, 
	CAST(COUNT(C.nombre) AS FLOAT)/(SELECT COUNT(*) FROM CLIENTE) * 100 'porcentaje de clientes'
FROM PAIS P 
	LEFT JOIN CLIENTE C
ON P.id = C.id_pais
GROUP BY P.id, P.pais
ORDER BY COUNT(C.nombre) DESC;

-- paso 5 opcional: dando formato
SELECT P.id, P.pais, 
	CONCAT(CAST(COUNT(C.nombre) AS FLOAT)/(SELECT COUNT(*) FROM CLIENTE) * 100,'%') 'porcentaje de clientes'
FROM PAIS P 
	LEFT JOIN CLIENTE C
ON P.id = C.id_pais
GROUP BY P.id, P.pais
ORDER BY COUNT(C.nombre) DESC;

-- 1.2  Mostrar la lista de clientes 'VIP'
--		Un cliente VIP se define si el promedio del total de cada reserva es mayor a $1000
-- partiendo de esta consulta:
SELECT R.id, R.checkin, R.checkout, C.nombre, H.precio*DATEDIFF (DAY, R.checkin, R.checkout) 'total reserva habitaci�n', SUM(ISNULL(S.precio,0.00)) 'precio servicio', SUM(ISNULL(S.precio,0.00))+H.precio*DATEDIFF (DAY, R.checkin, R.checkout) 'TOTAL RESERVA'
FROM RESERVA R 
	LEFT JOIN EXTRAS X
ON R.id = X.id_reserva
	LEFT JOIN SERVICIO S
ON S.id = X.id_servicio
	LEFT JOIN CLIENTE C
ON C.id = R.id_cliente
	LEFT JOIN HABITACION H
ON H.id = R.id_habitacion
GROUP BY R.id, R.checkin, R.checkout, C.nombre,H.precio, H.precio*DATEDIFF (DAY, R.checkin, R.checkout)
ORDER BY R.id ASC;

/*
NOTA: la siguiente instrucci�n falla porque no es posible utilizar una funcion de agregacion
dentro de otra funcion de agregacion, para el caso AGV(SUM(...))
SELECT R.id, C.id 'id cliente', C.nombre, AVG(SUM(ISNULL(S.precio,0.00))+H.precio*DATEDIFF (DAY, R.checkin, R.checkout)) 'PROMEDIO DE RESERVA'
FROM RESERVA R 
	LEFT JOIN EXTRAS X
ON R.id = X.id_reserva
	LEFT JOIN SERVICIO S
ON S.id = X.id_servicio
	LEFT JOIN CLIENTE C
ON C.id = R.id_cliente
	LEFT JOIN HABITACION H
ON H.id = R.id_habitacion
GROUP BY R.id, C.id, C.nombre,H.precio, H.precio*DATEDIFF (DAY, R.checkin, R.checkout)
ORDER BY C.id ASC;
*/

-- paso 1: partiendo de la siguiente consulta, que sabemos, calcula el total de cada reserva incluyen los extra y el precio de la habitaci�n reservada.
SELECT R.id 'id_reserva', R.checkin, R.checkout, C.id 'id_cliente', C.nombre, H.precio*DATEDIFF (DAY, R.checkin, R.checkout) 'total_res_habitacion', SUM(ISNULL(S.precio,0.00)) 'precio_servicio', SUM(ISNULL(S.precio,0.00))+H.precio*DATEDIFF (DAY, R.checkin, R.checkout) 'total_reserva'
FROM RESERVA R 
	LEFT JOIN EXTRAS X
ON R.id = X.id_reserva
	LEFT JOIN SERVICIO S
ON S.id = X.id_servicio
	LEFT JOIN CLIENTE C
ON C.id = R.id_cliente
	LEFT JOIN HABITACION H
ON H.id = R.id_habitacion
GROUP BY R.id, R.checkin, R.checkout, C.id, C.nombre,H.precio, H.precio*DATEDIFF (DAY, R.checkin, R.checkout)
ORDER BY C.id ASC;


-- paso 2: replanteando la consulta utilizando subqueries.
SELECT DETALLE_RESERVA.id_cliente, DETALLE_RESERVA.nombre, AVG(DETALLE_RESERVA.total_reserva) 'promedio reserva'
FROM (
	SELECT R.id 'id_reserva', R.checkin, R.checkout, C.id 'id_cliente', C.nombre, H.precio*DATEDIFF (DAY, R.checkin, R.checkout) 'total_res_habitacion', SUM(ISNULL(S.precio,0.00)) 'precio_servicio', SUM(ISNULL(S.precio,0.00))+H.precio*DATEDIFF (DAY, R.checkin, R.checkout) 'total_reserva'
	FROM RESERVA R 
		LEFT JOIN EXTRAS X
	ON R.id = X.id_reserva
		LEFT JOIN SERVICIO S
	ON S.id = X.id_servicio
		LEFT JOIN CLIENTE C
	ON C.id = R.id_cliente
		LEFT JOIN HABITACION H
	ON H.id = R.id_habitacion
	GROUP BY R.id, R.checkin, R.checkout, C.id, C.nombre,H.precio, H.precio*DATEDIFF (DAY, R.checkin, R.checkout)
) DETALLE_RESERVA
GROUP BY DETALLE_RESERVA.id_cliente, DETALLE_RESERVA.nombre
ORDER BY DETALLE_RESERVA.id_cliente ASC;

-- paso 3: calculando los promedios mayores a $1000
SELECT DETALLE_RESERVA.id_cliente, DETALLE_RESERVA.nombre, AVG(DETALLE_RESERVA.total_reserva) 'promedio reserva'
FROM (
	SELECT R.id 'id_reserva', R.checkin, R.checkout, C.id 'id_cliente', C.nombre, H.precio*DATEDIFF (DAY, R.checkin, R.checkout) 'total_res_habitacion', SUM(ISNULL(S.precio,0.00)) 'precio_servicio', SUM(ISNULL(S.precio,0.00))+H.precio*DATEDIFF (DAY, R.checkin, R.checkout) 'total_reserva'
	FROM RESERVA R 
		LEFT JOIN EXTRAS X
	ON R.id = X.id_reserva
		LEFT JOIN SERVICIO S
	ON S.id = X.id_servicio
		LEFT JOIN CLIENTE C
	ON C.id = R.id_cliente
		LEFT JOIN HABITACION H
	ON H.id = R.id_habitacion
	GROUP BY R.id, R.checkin, R.checkout, C.id, C.nombre,H.precio, H.precio*DATEDIFF (DAY, R.checkin, R.checkout)
) DETALLE_RESERVA
GROUP BY DETALLE_RESERVA.id_cliente, DETALLE_RESERVA.nombre
HAVING AVG(DETALLE_RESERVA.total_reserva) >= 1000
ORDER BY DETALLE_RESERVA.id_cliente ASC;


-- 1.3	Agregar una columna a la tabla cliente llamada 'vip' de tipo entero
--		Configurar el valor 1 a todos los usuarios cuyo promedio de 
--		reservas sea mayor a $1000
SELECT * FROM CLIENTE;

-- Paso 1: creando nueva columna llamada 'vip'
ALTER TABLE CLIENTE ADD vip INT NOT NULL DEFAULT 0;
SELECT * FROM CLIENTE;

-- Paso 2: asignando el tipo vip = 1 a los clientes vip (de forma est�tica, no conveniente para una gran cantidad de datos)
--UPDATE CLIENTE SET vip = 1 WHERE id IN (4, 14, 19, 20);

-- Paso 2 v2: 
UPDATE CLIENTE SET vip = 1 
WHERE id IN (
			SELECT DETALLE_RESERVA.id_cliente
			FROM (
				SELECT R.id 'id_reserva', R.checkin, R.checkout, C.id 'id_cliente', C.nombre, H.precio*DATEDIFF (DAY, R.checkin, R.checkout) 'total_res_habitacion', SUM(ISNULL(S.precio,0.00)) 'precio_servicio', SUM(ISNULL(S.precio,0.00))+H.precio*DATEDIFF (DAY, R.checkin, R.checkout) 'total_reserva'
				FROM RESERVA R 
					LEFT JOIN EXTRAS X
				ON R.id = X.id_reserva
					LEFT JOIN SERVICIO S
				ON S.id = X.id_servicio
					LEFT JOIN CLIENTE C
				ON C.id = R.id_cliente
					LEFT JOIN HABITACION H
				ON H.id = R.id_habitacion
				GROUP BY R.id, R.checkin, R.checkout, C.id, C.nombre,H.precio, H.precio*DATEDIFF (DAY, R.checkin, R.checkout)
			) DETALLE_RESERVA
			GROUP BY DETALLE_RESERVA.id_cliente, DETALLE_RESERVA.nombre
			HAVING AVG(DETALLE_RESERVA.total_reserva) >= 1000
			);
SELECT * FROM CLIENTE;


-- 1.4 �Cual es el servicio que m�s ganancias genera?
-- servicio que mayores ganancias tiene
SELECT TOP 1 S.id, S.nombre, SUM(S.precio) 'ganancia'
FROM SERVICIO S, EXTRAS X
WHERE S.id = X.id_servicio
GROUP BY S.id, S.nombre
ORDER BY SUM(S.precio) DESC;

-- servicio que menores ganancias tiene
SELECT TOP 1 S.id, S.nombre, SUM(S.precio) 'ganancia'
FROM SERVICIO S, EXTRAS X
WHERE S.id = X.id_servicio
GROUP BY S.id, S.nombre
ORDER BY SUM(S.precio) ASC;

-- mostrando el mismo resultado pero en una sola consulta
-- NOTA: procedimientso no eficientes porque utiliza datos est�ticos.
SELECT S.id, S.nombre, SUM(S.precio) 'ganancia'
FROM SERVICIO S, EXTRAS X
WHERE S.id = X.id_servicio
GROUP BY S.id, S.nombre
HAVING SUM(S.precio) = 28.15 
	OR SUM(S.precio) = 874.50
ORDER BY SUM(S.precio) DESC;

SELECT S.id, S.nombre, SUM(S.precio) 'ganancia'
FROM SERVICIO S, EXTRAS X
WHERE S.id = X.id_servicio
	AND (S.id = 2 OR S.id = 7)
GROUP BY S.id, S.nombre
ORDER BY SUM(S.precio) DESC;


-- mostrando el mismo resultado pero en una sola consulta 
-- NOTA: Utilizando subconsultas
SELECT S.id, S.nombre, SUM(S.precio) 'ganancia'
FROM SERVICIO S, EXTRAS X
WHERE S.id = X.id_servicio
	AND (
		S.id = (
			SELECT TOP 1 S.id
			FROM SERVICIO S, EXTRAS X
			WHERE S.id = X.id_servicio
			GROUP BY S.id, S.nombre
			ORDER BY SUM(S.precio) DESC
		)
	OR
		S.id = (
			SELECT TOP 1 S.id
			FROM SERVICIO S, EXTRAS X
			WHERE S.id = X.id_servicio
			GROUP BY S.id, S.nombre
			ORDER BY SUM(S.precio) ASC		
		)
	)
GROUP BY S.id, S.nombre
ORDER BY SUM(S.precio) DESC;
