--****************************************************
-- Bases de datos: Introduccion a T-SQL
-- Autor: Erick Varela
-- Correspondencia: evarela@uca.edu.sv
-- Version: 1.0
--****************************************************
USE HotelManagementDB;
SET LANGUAGE us_english;
--*****************************************************

-- *****************************************************
-- 1.	T-SQL
-- *****************************************************
--1.0	declarando variables T-SQL
DECLARE @variable VARCHAR(50);
-- como asignar valor a una variable
SET @variable = 'Bases de datos 2021';
-- Imprimiendo variables.
PRINT @variable;
-- Concatenando cadenas de texto:
PRINT @variable + ', Ciclo 01.';

-- 1.1	Concantenando numeros
DECLARE @numero INT;
SET @numero = 1;
-- PRINT @variable + @numero;  -- Falla!!
PRINT @variable + CONVERT (VARCHAR,@numero);

--2.0	Integrando T-SQL a consultas SQL.
--		Mostrar la categoria de habitacion gener� m�s de $100 en el primer trimestre de 2010 para el hotel Semper:
-- Consulta original:
/*SELECT th.nombre tipo_habitacion, SUM(h.precio) ganancia
FROM reserva r, habitacion h, tipo_habitacion th, hotel ho
WHERE r.id_habitacion = h.id
	AND h.id_tipo = th.id
	AND h.id_hotel = ho.id
	AND r.checkin BETWEEN '2010-01-01' AND '2010-03-31'
	AND ho.nombre = 'Semper'
GROUP BY th.nombre
HAVING SUM(h.precio) > 100
ORDER BY th.nombre ASC;*/

DECLARE @nombre_hotel VARCHAR(20), 
		@ganancia_objetivo INT,
		@fecha_inicial DATE,
		@fecha_final DATE;
SET @nombre_hotel = 'Semper';
SET	@ganancia_objetivo = 100;
SET @fecha_inicial = '2010-01-01';
SET @fecha_final = '2010-03-31';
SELECT th.nombre tipo_habitacion, SUM(h.precio) ganancia
FROM reserva r, habitacion h, tipo_habitacion th, hotel ho
WHERE r.id_habitacion = h.id
	AND h.id_tipo = th.id
	AND h.id_hotel = ho.id
	AND r.checkin BETWEEN @fecha_inicial AND @fecha_final
	AND ho.nombre = @nombre_hotel
GROUP BY th.nombre
HAVING SUM(h.precio) > @ganancia_objetivo
ORDER BY th.nombre ASC;


-- 2.1	�cuantos clientes hay por cada pais?
-- Consulta original:
/*SELECT p.pais, COUNT(c.nombre) as 'cantidad de clientes'
FROM pais p LEFT JOIN cliente c
ON p.id = c.id_pais
GROUP BY  p.pais
ORDER BY COUNT(c.nombre) DESC;*/

SELECT p.pais, COUNT(c.nombre) as 'cantidad de clientes'
FROM pais p LEFT JOIN cliente c
ON p.id = c.id_pais
GROUP BY  p.pais
ORDER BY COUNT(c.nombre) DESC;

--Utilizando CASE para dar formato a la salida de una consulta.
SELECT p.id, p.pais, 
	CASE COUNT(c.nombre) 
		WHEN 0 THEN
			'Ning�n cliente' 
		WHEN 1 THEN
			'1 Cliente'
		ELSE
			CONCAT(COUNT(c.nombre),' clientes')
	END AS 'cantidad de clientes'
FROM pais p LEFT JOIN cliente c
ON p.id = c.id_pais
GROUP BY  p.id, p.pais
ORDER BY COUNT(c.nombre) DESC;


-- 3.0	Eliminando sub-consultas al utilizar T-SQL
-- 3.1	�Cual es el porcentaje de clientes que vienen de cada pais?
-- partiendo de esta subconsulta:
/*
SELECT P.id, P.pais, CONCAT((CAST(COUNT(C.nombre) AS FLOAT)/(SELECT COUNT(*) FROM CLIENTE))*100,'%') 'cantidad de clientes'
FROM PAIS P 
	LEFT JOIN CLIENTE C
ON P.id = C.id_pais
GROUP BY P.id, P.pais
ORDER BY COUNT(C.nombre) DESC;*/
SELECT P.id, P.pais, 
	CONCAT((CAST(COUNT(C.nombre) AS FLOAT)/(SELECT COUNT(*) FROM CLIENTE))*100,'%') 'cantidad de clientes'
FROM PAIS P 
	LEFT JOIN CLIENTE C
ON P.id = C.id_pais
GROUP BY P.id, P.pais
ORDER BY COUNT(C.nombre) DESC;


-- Obtener la cantidad de clientes y guardarlos en una variable
-- Realizar la consulta y en lugar de utilizar un valor constante, utilizar la variable.
DECLARE @cantidad_clientes INT;
--SET @cantidad_clientes = SELECT COUNT(*) FROM CLIENTE; -- Falla!!! 
SELECT @cantidad_clientes = COUNT(*) FROM CLIENTE;

SELECT P.id, P.pais, 
	CONCAT((CAST(COUNT(C.nombre) AS FLOAT)/(@cantidad_clientes))*100,'%') 'cantidad de clientes'
FROM PAIS P 
	LEFT JOIN CLIENTE C
ON P.id = C.id_pais
GROUP BY P.id, P.pais
ORDER BY COUNT(C.nombre) DESC;

-- 3.2  Mostrar la lista de clientes 'VIP'
--		Un cliente VIP se define si el promedio del total de cada reserva es mayor a $1000
-- partiendo de esta subconsulta:
/*SELECT RESERVA_DETALLE.nombre 'nombre cliente', AVG(RESERVA_DETALLE.TOTAL_RESERVA) 'promedio de reserva'
FROM (
	SELECT R.id, R.checkin, R.checkout, C.nombre, H.precio*DATEDIFF (DAY, R.checkin, R.checkout) 'total_reserva_habitaci�n', SUM(ISNULL(S.precio,0.00)) 'precio_servicio', SUM(ISNULL(S.precio,0.00))+H.precio*DATEDIFF (DAY, R.checkin, R.checkout) 'TOTAL_RESERVA'
	FROM RESERVA R 
		LEFT JOIN EXTRAS X
	ON R.id = X.id_reserva
		LEFT JOIN SERVICIO S
	ON S.id = X.id_servicio
		LEFT JOIN CLIENTE C
	ON C.id = R.id_cliente
		LEFT JOIN HABITACION H
	ON H.id = R.id_habitacion
	GROUP BY R.id, R.checkin, R.checkout, C.nombre,H.precio, H.precio*DATEDIFF (DAY, R.checkin, R.checkout)
) RESERVA_DETALLE
GROUP BY RESERVA_DETALLE.nombre
HAVING AVG(RESERVA_DETALLE.TOTAL_RESERVA) >= 1000
ORDER BY RESERVA_DETALLE.nombre ASC;*/

SELECT RESERVA_DETALLE.nombre 'nombre cliente', AVG(RESERVA_DETALLE.TOTAL_RESERVA) 'promedio de reserva'
FROM (
	SELECT R.id, R.checkin, R.checkout, C.nombre, H.precio*DATEDIFF (DAY, R.checkin, R.checkout) 'total_reserva_habitaci�n', SUM(ISNULL(S.precio,0.00)) 'precio_servicio', SUM(ISNULL(S.precio,0.00))+H.precio*DATEDIFF (DAY, R.checkin, R.checkout) 'TOTAL_RESERVA'
	FROM RESERVA R 
		LEFT JOIN EXTRAS X
	ON R.id = X.id_reserva
		LEFT JOIN SERVICIO S
	ON S.id = X.id_servicio
		LEFT JOIN CLIENTE C
	ON C.id = R.id_cliente
		LEFT JOIN HABITACION H
	ON H.id = R.id_habitacion
	GROUP BY R.id, R.checkin, R.checkout, C.nombre,H.precio, H.precio*DATEDIFF (DAY, R.checkin, R.checkout)
) RESERVA_DETALLE
GROUP BY RESERVA_DETALLE.nombre
HAVING AVG(RESERVA_DETALLE.TOTAL_RESERVA) >= 1000
ORDER BY RESERVA_DETALLE.nombre ASC;


DECLARE @RESERVA_DETALLE TABLE(
	id_reserva INT,
	checkin DATETIME,
	checkout DATETIME, 
	nombre_cliente VARCHAR(50),
	precio_habitacion MONEY,
	precio_servicios MONEY,
	total_reserva MONEY
);
INSERT INTO @RESERVA_DETALLE (id_reserva, checkin, checkout,nombre_cliente, precio_habitacion, precio_servicios,total_reserva)
SELECT R.id, R.checkin, R.checkout, C.nombre, H.precio*DATEDIFF (DAY, R.checkin, R.checkout) 'total_reserva_habitaci�n', SUM(ISNULL(S.precio,0.00)) 'precio_servicio', SUM(ISNULL(S.precio,0.00))+H.precio*DATEDIFF (DAY, R.checkin, R.checkout) 'TOTAL_RESERVA'
FROM RESERVA R 
	LEFT JOIN EXTRAS X
ON R.id = X.id_reserva
	LEFT JOIN SERVICIO S
ON S.id = X.id_servicio
	LEFT JOIN CLIENTE C
ON C.id = R.id_cliente
	LEFT JOIN HABITACION H
ON H.id = R.id_habitacion
GROUP BY R.id, R.checkin, R.checkout, C.nombre,H.precio, H.precio*DATEDIFF (DAY, R.checkin, R.checkout)

SELECT RESERVA_DETALLE.nombre_cliente 'nombre cliente', AVG(RESERVA_DETALLE.TOTAL_RESERVA) 'promedio de reserva'
FROM @RESERVA_DETALLE RESERVA_DETALLE
GROUP BY RESERVA_DETALLE.nombre_cliente
HAVING AVG(RESERVA_DETALLE.TOTAL_RESERVA) >= 1000
ORDER BY RESERVA_DETALLE.nombre_cliente ASC;