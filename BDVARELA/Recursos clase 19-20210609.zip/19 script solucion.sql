--****************************************************
-- Bases de datos: Funciones y procedimientos almacenados
-- Autor: Erick Varela
-- Correspondencia: evarela@uca.edu.sv
-- Version: 1.0
--****************************************************
USE HotelManagementDB;
SET LANGUAGE us_english;
--*****************************************************

-- *****************************************************
-- 1.	Funciones
-- *****************************************************
-- 1.1	Crear una funcion que tome como parametro el id de un cliente
--		y retorne el nombre del pais del que procede dicho cliente.
CREATE FUNCTION PAIS_CLIENTE (@id_cliente INT)
	RETURNS VARCHAR(30)
	AS BEGIN
		DECLARE @nombre_pais VARCHAR(30);
		SELECT @nombre_pais = p.pais
		FROM CLIENTE C, PAIS P
		WHERE P.id = C.id_pais
			AND C.id = @id_cliente;
		RETURN @nombre_pais;
	END;


-- 1.1.1	Ejecutando la funci�n.
SELECT dbo.PAIS_CLIENTE(15) AS 'pais del cliente';

-- 1.1.2	Ejecutando la funci�n en una consulta.
SELECT id, nombre, tipo_cliente,correo, dbo.PAIS_CLIENTE(id) AS 'pais del cliente'
FROM CLIENTE;

-- 1.2	Crear una funcion que calcule el monto total de los servicios extras adquiridos por un cliente en una reserva.
--		Si la reserva no tiene servicios extras, la funcion retorna 0.0
--		como par�metro se recibir� el id de una reserva

CREATE FUNCTION OBTENER_EXTRAS (@id_reserva INT)
	RETURNS MONEY
	AS BEGIN
		-- declarando variables necesarias
		DECLARE @total_servicios MONEY;

		SELECT @total_servicios = SUM(S.precio)
		FROM RESERVA R
			LEFT JOIN EXTRAS X
		ON R.id = X.id_reserva
			LEFT JOIN SERVICIO S
		ON S.id = X.id_servicio
		WHERE R.id = @id_reserva
		GROUP BY R.id;

		IF @total_servicios IS NULL 
		BEGIN
			RETURN 0.0;
		END;
			
		RETURN @total_servicios;
	END;


-- 2.1.1	Calcular el total de cada reserva 
-- consulta realizada en la clase 15:
/*
SELECT R.id, R.checkin, R.checkout, C.nombre, H.precio*DATEDIFF (DAY, R.checkin, R.checkout) 'total reserva habitaci�n', SUM(ISNULL(S.precio,0.00)) 'precio servicio', SUM(ISNULL(S.precio,0.00))+H.precio*DATEDIFF (DAY, R.checkin, R.checkout) 'TOTAL RESERVA'
FROM RESERVA R 
	LEFT JOIN EXTRAS X
ON R.id = X.id_reserva
	LEFT JOIN SERVICIO S
ON S.id = X.id_servicio
	LEFT JOIN CLIENTE C
ON C.id = R.id_cliente
	LEFT JOIN HABITACION H
ON H.id = R.id_habitacion
GROUP BY R.id, R.checkin, R.checkout, C.nombre,H.precio, H.precio*DATEDIFF (DAY, R.checkin, R.checkout)
ORDER BY R.id ASC;
*/
-- consulta utilizando funciones.

SELECT R.id, R.checkin, R.checkout, C.nombre, 
	H.precio*DATEDIFF (DAY, R.checkin, R.checkout) 'subtotal habitacion',
	H.precio*DATEDIFF (DAY, R.checkin, R.checkout) + dbo.OBTENER_EXTRAS(R.id) 'TOTAL'
FROM RESERVA R, HABITACION H, CLIENTE C
WHERE C.id = R.id_cliente
	AND H.id = R.id_habitacion;



-- 1.3	Crear una funcion que calcule el total de una reserva
--		La funcion recibira como parametro el id de una reserva.
--		Para el calculo de los servicios extra, se debe utilizar 
--		la funci�n OBTENER_EXTRAS creada en el ejercicio anterior.
CREATE FUNCTION OBTENER_TOTAL (@id_reserva INT)
	RETURNS MONEY
	AS BEGIN
		-- declaraci�n de variables
		DECLARE @total MONEY;

		SELECT @total = H.precio*DATEDIFF (DAY, R.checkin, R.checkout) + dbo.OBTENER_EXTRAS(R.id)
		FROM RESERVA R, HABITACION H
		WHERE H.id = R.id_habitacion
			AND R.id = @id_reserva;

		RETURN @total;
	END;


-- 1.3.1	Haciendo uso de la funcion
SELECT R.id, R.checkin, R.checkout, C.nombre, dbo.OBTENER_TOTAL(R.id) 'TOTAL'
FROM CLIENTE C, RESERVA R
WHERE C.id = R.id_cliente;


-- 1.4	Crear la funcion llamada, RESERVA_DETALLE_S1. Debe mostrar el subtotal
--		obtenido de la multiplicaci�n del precio de la habitaci�n y el numero de dias reservados (A).
--		mostrar el total de la suma de los servicios extra incluidos (B).
--		y el total resultante de toda la reserva (A+B).




CREATE FUNCTION RESERVA_DETALLE_S1 ()
	RETURNS TABLE 
	AS 
		RETURN (
			SELECT R.id, R.checkin, R.checkout, C.nombre, 
				H.precio*DATEDIFF (DAY, R.checkin, R.checkout) 'subtotal habitacion',
				dbo.OBTENER_EXTRAS(R.id) 'subtotal extras',
				dbo.OBTENER_TOTAL(R.id) 'TOTAL'
			FROM CLIENTE C, RESERVA R, HABITACION H
			WHERE C.id = R.id_cliente
				AND H.id = R.id_habitacion	
		);

SELECT * FROM dbo.RESERVA_DETALLE_S1();


-- *****************************************************
-- 2.	Procedimientos almacenados basicos.
-- *****************************************************

-- 2.1	Crear un procedimiento almacenado que reciba como par�metro el id
--		de una habitaci�n y retorne la cantidad de veces que ha sido reservada



CREATE PROCEDURE OBTENER_RESERVAS_HABITACION
	@id_habitacion INT
AS BEGIN
	-- declarando variables
	DECLARE @cantidad_de_reservas INT;
	SELECT @cantidad_de_reservas = COUNT (R.id) 
	FROM HABITACION H, RESERVA R
	WHERE H.id = R.id_habitacion
		AND H.id = @id_habitacion
	GROUP BY H.id;

	IF @cantidad_de_reservas IS NULL
		PRINT ('La habitacion con id ='+
				CAST(@id_habitacion AS VARCHAR) + ', ha tenido 0 reservas.');
	ELSE 
		PRINT('La habitacion con id ='+
				CAST(@id_habitacion AS VARCHAR) + ', ha tenido ' +
				CAST(@cantidad_de_reservas AS VARCHAR) + ' reservas.');
END;

DROP PROCEDURE OBTENER_RESERVAS_HABITACION;

EXEC OBTENER_RESERVAS_HABITACION 1;
