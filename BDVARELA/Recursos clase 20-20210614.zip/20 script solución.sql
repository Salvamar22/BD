--****************************************************
-- Bases de datos: Transacciones y cursores
-- Autor: Erick Varela
-- Correspondencia: evarela@uca.edu.sv
-- Version: 1.0
--****************************************************
USE HotelManagementDB;
SET LANGUAGE us_english

-- IMPORTANTE:
-- Para poder realizar algunos ejercicion de esta clase es necesario actualizar la base 
-- de datos HotelManagementDB, por lo que se debe:
--		* Agregar la columna "puntos_cliente_frecuente" de tipo INT a la tabla CLIENTE.
--		* Actualizar la columna reci�n creada con algunos datos.
ALTER TABLE CLIENTE ADD puntos_cliente_frecuente INT;

UPDATE CLIENTE SET puntos_cliente_frecuente = 2949 WHERE id=1;
UPDATE CLIENTE SET puntos_cliente_frecuente = 3057 WHERE id=2;
UPDATE CLIENTE SET puntos_cliente_frecuente = 4586 WHERE id=3;
UPDATE CLIENTE SET puntos_cliente_frecuente = 9772 WHERE id=4;
UPDATE CLIENTE SET puntos_cliente_frecuente = 4515 WHERE id=5;
UPDATE CLIENTE SET puntos_cliente_frecuente = 3335 WHERE id=6;
UPDATE CLIENTE SET puntos_cliente_frecuente = 9447 WHERE id=7;
UPDATE CLIENTE SET puntos_cliente_frecuente = 2274 WHERE id=8;
UPDATE CLIENTE SET puntos_cliente_frecuente = 2889 WHERE id=9;
UPDATE CLIENTE SET puntos_cliente_frecuente = 4686 WHERE id=10;
UPDATE CLIENTE SET puntos_cliente_frecuente = 4257 WHERE id=11;
UPDATE CLIENTE SET puntos_cliente_frecuente = 1480 WHERE id=12;
UPDATE CLIENTE SET puntos_cliente_frecuente = 4409 WHERE id=13;
UPDATE CLIENTE SET puntos_cliente_frecuente = 1012 WHERE id=14;
UPDATE CLIENTE SET puntos_cliente_frecuente = 7395 WHERE id=15;
UPDATE CLIENTE SET puntos_cliente_frecuente = 1663 WHERE id=16;
UPDATE CLIENTE SET puntos_cliente_frecuente = 8876 WHERE id=17;
UPDATE CLIENTE SET puntos_cliente_frecuente = 6171 WHERE id=18;
UPDATE CLIENTE SET puntos_cliente_frecuente = 1722 WHERE id=19;
UPDATE CLIENTE SET puntos_cliente_frecuente = 5246 WHERE id=20;
UPDATE CLIENTE SET puntos_cliente_frecuente = 4266 WHERE id=21;
UPDATE CLIENTE SET puntos_cliente_frecuente = 3652 WHERE id=22;
UPDATE CLIENTE SET puntos_cliente_frecuente = 4054 WHERE id=23;
UPDATE CLIENTE SET puntos_cliente_frecuente = 8517 WHERE id=24;
UPDATE CLIENTE SET puntos_cliente_frecuente = 1907 WHERE id=25;

SELECT * FROM CLIENTE;

--*****************************************************

-- 1.0 	Crear un procedimiento almacenado que permita registrar nuevas reservas
--		Como argumentos se reciben: id de la reserva, la fecha de checkin y checkout, el id del
--		 cliente y el id de la habitacion.
-- DROP PROCEDURE BOOKING;

ALTER PROCEDURE BOOKING 
	@id_reserva INT,
	@checkin DATETIME,
	@checkout DATETIME,
	@id_cliente INT,
	@id_habitacion INT
AS BEGIN
	INSERT INTO RESERVA VALUES (@id_reserva, @checkin, @checkout, @id_cliente, @id_habitacion);
END;

-- Ejecutando procedimiento almacenado
-- DELETE FROM RESERVA WHERE id = 101 OR id = 102;
EXEC BOOKING 101,'2010-01-11 15:00:00' ,'2010-01-15 13:00:00',13,3;
EXEC BOOKING 102,'2010-01-10 15:00:00' ,'2010-01-12 13:00:00',9,3;

-- Verificando datos:
-- �Se observa alguna anomal�a en los datos?
SELECT * FROM RESERVA WHERE id_habitacion = 3;

--*****************************************************
--	TRANSACCIONES
--*****************************************************
-- 2.0	Crear un procedimiento almacenado que permita transferir puntos de cliente frecuente entre
--		2 usuarios. Como parametros se deberan recibir el id del usuario emisor, el id del usuario
--		receptor, y la cantidad de puntos a transferir.
--		NOTA: En la primera version de este ejercicio provocar un error de semantica y observar el resultado

ALTER PROCEDURE TRANSFERIR_PUNTOS_S1
	@id_emisor INT,
	@id_receptor INT,
	@puntos INT
AS BEGIN
	-- Valindando que el usuario tenga puntos suficientes para transferir
	DECLARE @puntos_emisor INT;
	SELECT @puntos_emisor = puntos_cliente_frecuente FROM CLIENTE WHERE id = @id_emisor;
	IF @puntos_emisor <@puntos
	BEGIN
		PRINT 'ERROR: puntos insuficientes... solo dispone de ' + CAST(@puntos_emisor AS VARCHAR);
	END
	ELSE BEGIN
		BEGIN TRY 
			-- Restando puntos del emisor
			UPDATE CLIENTE SET puntos_cliente_frecuente = puntos_cliente_frecuente - @puntos
			WHERE id = @id_emisor;
			-- incluyendo error semantico para verificar que sucede:
			DECLARE @error_provocado INT;
			SELECT @error_provocado = 10/0;
			-- sumando puntos al receptor
			UPDATE CLIENTE SET puntos_cliente_frecuente = puntos_cliente_frecuente + @puntos
			WHERE id = @id_receptor;
		END TRY
		BEGIN CATCH
			DECLARE @ERROR_MENSAJE VARCHAR(100);
			SELECT @ERROR_MENSAJE = ERROR_MESSAGE();
			PRINT 'ERROR: ' + @ERROR_MENSAJE;
		END CATCH
	END;
END;


--DROP PROCEDURE TRANSFERIR_PUNTOS;
UPDATE CLIENTE SET puntos_cliente_frecuente = 2949 WHERE id=1;
UPDATE CLIENTE SET puntos_cliente_frecuente = 3057 WHERE id=2;
-- Ejecutando procedimiento almacenado (se espera un error)
EXEC TRANSFERIR_PUNTOS_S1 1, 2, 2000;

-- Verificando datos (se espera un error: el intercambio no se realizo correctamente).
SELECT * FROM CLIENTE WHERE id = 1 OR id = 2;

-- 2.1	Crear una versi�n 2 del procedimiento almacenado anterior
--		Utilizar transacciones
ALTER PROCEDURE TRANSFERIR_PUNTOS_S1
	@id_emisor INT,
	@id_receptor INT,
	@puntos INT
AS BEGIN
	-- Valindando que el usuario tenga puntos suficientes para transferir
	DECLARE @puntos_emisor INT;
	SELECT @puntos_emisor = puntos_cliente_frecuente FROM CLIENTE WHERE id = @id_emisor;
	IF @puntos_emisor <@puntos
	BEGIN
		PRINT 'ERROR: puntos insuficientes... solo dispone de ' + CAST(@puntos_emisor AS VARCHAR);
	END
	ELSE BEGIN
		BEGIN TRY 
			BEGIN TRANSACTION TRANSFERIR_PUNTOS
			-- Restando puntos del emisor
			UPDATE CLIENTE SET puntos_cliente_frecuente = puntos_cliente_frecuente - @puntos
			WHERE id = @id_emisor;
			-- incluyendo error semantico para verificar que sucede:
			DECLARE @error_provocado INT;
			SELECT @error_provocado = 10/0;
			-- sumando puntos al receptor
			UPDATE CLIENTE SET puntos_cliente_frecuente = puntos_cliente_frecuente + @puntos
			WHERE id = @id_receptor;
			COMMIT TRANSACTION TRANSFERIR_PUNTOS
		END TRY
		BEGIN CATCH
			DECLARE @ERROR_MENSAJE VARCHAR(100);
			SELECT @ERROR_MENSAJE = ERROR_MESSAGE();
			PRINT 'ERROR: ' + @ERROR_MENSAJE;
			ROLLBACK TRANSACTION TRANSFERIR_PUNTOS
		END CATCH
	END;
END;

--DROP PROCEDURE TRANSFERIR_PUNTOS;
UPDATE CLIENTE SET puntos_cliente_frecuente = 2949 WHERE id=1;
UPDATE CLIENTE SET puntos_cliente_frecuente = 3057 WHERE id=2;
-- Ejecutando procedimiento almacenado (se espera un error)
EXEC TRANSFERIR_PUNTOS 1, 2, 2000;

-- Verificando datos
SELECT * FROM CLIENTE WHERE id = 1 OR id = 2;


--*****************************************************
--	CURSORES
--*****************************************************
-- Procedimientos almacenados con tratamiento de tablas.
-- 2.2. Crear un procedimiento almacenado que reciba como parametros dos enteros
--		El objetivo es mostrar la ganancia de cada hotel y el total, es decir la suma
--		de la ganancia.
--		Parametro 1: numero entero entre 1 y 12 que representa un mes
--		Parametro 2: numero entero que representa un a�o.

SELECT HO.nombre, SUM(dbo.OBTENER_TOTAL(R.id)) AS 'total'
FROM HOTEL HO, HABITACION H, RESERVA R
WHERE HO.id = H.id_hotel
	AND H.id = R.id_habitacion
	AND MONTH(R.checkin) = 1
	AND YEAR(R.checkin) = 2010
GROUP BY HO.id, HO.nombre
ORDER BY HO.id ASC;


ALTER PROCEDURE OBTENER_GANANCIA_MES
	@MM INT,
	@YY INT
AS BEGIN
	-- Declarando variables
	DECLARE @total_hoteles INT;
	SELECT @total_hoteles = COUNT(*) FROM HOTEL;
	DECLARE @total MONEY;
	DECLARE @hotel VARCHAR(25);
	DECLARE @hotel_ganancia MONEY;
	-- Creando cursor
	DECLARE cursor_ganancia CURSOR FOR
	SELECT HO.nombre, SUM(dbo.OBTENER_TOTAL(R.id)) AS 'total'
		FROM HOTEL HO, HABITACION H, RESERVA R
		WHERE HO.id = H.id_hotel
			AND H.id = R.id_habitacion
			AND MONTH(R.checkin) = @MM
			AND YEAR(R.checkin) = @YY
		GROUP BY HO.nombre;

	-- Recorriendo el cursor
	SET @total = 0.0;
	-- Abrir flujo del cursor
	OPEN cursor_ganancia;
	WHILE @total_hoteles > 0
	BEGIN
		-- Obteniendo fila del cursor
		FETCH cursor_ganancia INTO @hotel, @hotel_ganancia;
		PRINT 'HOTEL: ' + @hotel + ' -> Ganancia: ' + CAST(@hotel_ganancia AS VARCHAR);
		SET @total = @total + @hotel_ganancia;
		SET @total_hoteles = @total_hoteles - 1;
	END; 
	PRINT '--------------------------------------------';
	PRINT 'TOTAL: ' + CAST(@total AS VARCHAR);
	CLOSE cursor_ganancia;
	DEALLOCATE cursor_ganancia;
END;

-- Ejecutando procedimiento almacenado 
EXEC OBTENER_GANANCIA_MES 1, 2010;



