--****************************************************
-- Bases de datos: Triggers
-- Autor: Erick Varela
-- Correspondencia: evarela@uca.edu.sv
-- Version: 1.0
--****************************************************
USE HotelManagementDB;
SET LANGUAGE us_english;
--*****************************************************

-- *****************************************************
-- 1.	Procedimientos almacenados y triggers
-- *****************************************************
-- 1.1.	Crear un procedimiento almacenado que permita registrar nuevas reservas
--		Como argumentos se reciben: el la fecha de checkin y checkout, el id del cliente
--		y el id de la habitacion.
--		NOTA: Validar que la nueva reserva no se solape con otras reservas

CREATE PROCEDURE BOOKING_S1
	@id INT,
	@checkin VARCHAR(15),
	@checkout VARCHAR(15),
	@id_cliente INT,
	@id_habitacion INT
AS
BEGIN
	BEGIN TRY
		INSERT INTO RESERVA VALUES(@id,@checkin,@checkout,@id_cliente,@id_habitacion);		
	END TRY
	BEGIN CATCH
		PRINT ERROR_MESSAGE();
	END CATCH
END;

-- Creando trigger
CREATE TRIGGER CHECK_BOOKING_S1 
ON RESERVA 
AFTER INSERT
AS BEGIN
	-- declarando variables
	DECLARE @checkin DATETIME;
	DECLARE @checkout DATETIME;
	DECLARE @id_habitacion INT;
	DECLARE @resultado INT;
	-- obtener datos recién insertados
	SELECT @checkin = checkin, @checkout = checkout, @id_habitacion = id_habitacion 
	FROM INSERTED;
	
	SELECT @resultado = COUNT(*) FROM RESERVA 
	WHERE 
		((@checkin >= checkin AND @checkout <= checkout) OR
		(@checkin < checkin AND @checkout > checkin) OR
		(@checkin < checkin AND (@checkout BETWEEN checkin AND checkout)) OR
		((@checkin BETWEEN checkin AND checkout) AND @checkout > checkout)) AND
		id_habitacion = @id_habitacion;

	IF @resultado > 1 BEGIN
		ROLLBACK TRANSACTION;
		RAISERROR ('ERROR: consulta inválidad, ya existe una reserva en las fechas seleccionadas para esa habitación', 11, 1);
	END;
END;

-- Tabla "INSERTED"
--		INSERT: ultimo registro insertado
--		DELETE: no contiene nada
--		UPDATE: los registros que han sido actualizados 
-- Tabla "DELETED" 
--		INSERT: no contiene nada
--		DELETE: los registros eliminados
--		UPDATE: los registros antes de ser actualizados


-- Ejecutando procedimiento almacenado
-- DELETE FROM RESERVA WHERE id IN (101, 102, 104, 106);
EXEC BOOKING_S1 101,'2010-01-11 15:00:00' ,'2010-01-15 13:00:00',13,3; --falla
EXEC BOOKING_S1 102,'2010-01-10 15:00:00' ,'2010-01-12 13:00:00',9,3; --falla
EXEC BOOKING_S1 103,'2010-01-09 15:00:00' ,'2010-01-10 13:00:00',9,3; --funciona!
EXEC BOOKING_S1 104,'2010-01-10 15:00:00' ,'2010-01-14 13:00:00',9,3; --falla
EXEC BOOKING_S1 105,'2010-01-15 15:00:00' ,'2010-01-16 13:00:00',9,3; --funciona!
EXEC BOOKING_S1 106,'2010-01-16 15:00:00' ,'2010-01-17 13:00:00',9,3; --funciona!
EXEC BOOKING_S1 107,'2010-01-17 12:00:00' ,'2010-01-20 13:00:00',9,3; --falla
EXEC BOOKING_S1 107,'2010-01-12 15:00:00' ,'2010-01-14 13:00:00',9,3; --falla
SELECT * FROM RESERVA WHERE id_habitacion = 3
SELECT * FROM RESERVA;


-- 1.2.	Crear una tabla llamada "REGISTRO_PUNTOS_S#", el objetivo de esta tabla será funcionar
--		como registro de los intercambios de puntos de cliente frecuente que realizan los
--		clientes. La tabla debe almacenar: la fecha y hora de la transaccion, el id y nombre del
--		usuario involucrado, la cantidad de puntos antes y despues de la transacción y una 
--		descriptión breve del proceso realizado.
CREATE TABLE REGISTRO_PUNTOS_S1(
	id INT PRIMARY KEY IDENTITY,
	fecha DATETIME,
	id_cliente INT,
	nombre_cliente VARCHAR(50),
	puntos_ini INT,
	puntos_fin INT,
	descripcion VARCHAR(100)
);

ALTER PROCEDURE TRANSFERIR_PUNTOS
	@id_emisor INT,
	@id_receptor INT,
	@puntos INT
AS BEGIN 
	-- Validando si el usuario tiene suficientes puntos
	DECLARE @puntos_emisor INT;
	SELECT @puntos_emisor = puntos_cliente_frecuente 
	FROM CLIENTE WHERE id = @id_emisor;
	
	IF @puntos_emisor <= @puntos 
		PRINT 'ERROR: El usuario emisor no tiene suficientes puntos.';
	ELSE 
	BEGIN
		BEGIN TRY 
			BEGIN TRANSACTION TRANSFERIR_PUNTOS
			-- Restando puntos al emisor
			UPDATE CLIENTE 
				SET puntos_cliente_frecuente = puntos_cliente_frecuente - @puntos
			WHERE id = @id_emisor;
			-- Sumando puntos al receptor
			UPDATE CLIENTE 
				SET puntos_cliente_frecuente = puntos_cliente_frecuente + @puntos
			WHERE id = @id_receptor;
			COMMIT TRANSACTION TRANSFERIR_PUNTOS
		END TRY  
		BEGIN CATCH 
			DECLARE @ERROR_MESSAGE VARCHAR(100);
			SELECT @ERROR_MESSAGE=ERROR_MESSAGE();
			PRINT 'ERROR: ' + @ERROR_MESSAGE;
			ROLLBACK TRANSACTION TRANSFERIR_PUNTOS
		END CATCH  
	END;
END;

/*
UPDATE CLIENTE SET puntos_cliente_frecuente = 2949 WHERE id=1;
UPDATE CLIENTE SET puntos_cliente_frecuente = 3057 WHERE id=2;
*/
EXEC TRANSFERIR_PUNTOS 1, 2, 100;

-- Creando trigger
CREATE TRIGGER CHECK_POINTS 
ON CLIENTE
AFTER UPDATE 
AS BEGIN
	-- Seccion de variables
	DECLARE @fecha DATETIME;--
	DECLARE @id_cliente INT;--
	DECLARE @nombre VARCHAR(50);--
	DECLARE @puntos_ini INT;--
	DECLARE @puntos_fin INT; --
	DECLARE @descripcion VARCHAR(100); --
	-- Procesamiento de datos
	SELECT @fecha = GETDATE();
	SElECT @puntos_ini = puntos_cliente_frecuente FROM DELETED; 
	SElECT @id_cliente = id, @nombre = nombre, @puntos_fin = puntos_cliente_frecuente FROM INSERTED; 
	IF @puntos_ini > @puntos_fin 
		SET @descripcion = 'Cliente ha gastado o ha regalado puntos a otro cliente';
	IF @puntos_ini < @puntos_fin 
		SET @descripcion = 'Cliente ha recibido puntos';

	INSERT INTO REGISTRO_PUNTOS_S1 (fecha, id_cliente, nombre_cliente, puntos_ini, puntos_fin, descripcion)
		VALUES (@fecha, @id_cliente, @nombre, @puntos_ini, @puntos_fin, @descripcion);
END;


/*
UPDATE CLIENTE SET puntos_cliente_frecuente = 2949 WHERE id=1;
UPDATE CLIENTE SET puntos_cliente_frecuente = 3057 WHERE id=2;
*/
EXEC TRANSFERIR_PUNTOS 2, 1, 100;

-- Verificando datos
SELECT * FROM CLIENTE WHERE id = 1 OR id = 2;
-- Verificando contenido de la tabla REGISTRO_PUNTOS
SELECT * FROM REGISTRO_PUNTOS_S1;


