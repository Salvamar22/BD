--******************************************************
-- Bases de datos: Vistas y tablas temporales
-- Autor: Erick Varela
-- Correspondencia: evarela@uca.edu.sv
-- Version: 1.0
--******************************************************
USE HotelManagementDB;
SET LANGUAGE us_english;
--******************************************************

-- *****************************************************
-- 1.	Vistas
-- *****************************************************
-- 1.1.	Crear una vista que muestre el detalle de cada reserva, la vista debe incluir
--		el id de la reserva, el nombre del cliente, la fecha de checkin y checkout
--		y el total de la reserva incluyendo el precio de la habitaciòn y los servicios.
CREATE VIEW V_DETALLE_RESERVA AS 
SELECT id_reserva AS id, nombre AS nombre_cliente, checkin AS fecha_ini, checkout AS fecha_fin,  SUM(total_reserva) AS total_reserva
FROM (
	SELECT r.id id_reserva, c.nombre, r.checkin, r.checkout,  
				h.precio + ISNULL(SUM(s.precio), 0) AS total_reserva
	FROM reserva r LEFT JOIN extras x
			ON r.id = x.id_reserva
		LEFT JOIN servicio s
		ON x.id_servicio = s.id
		LEFT JOIN habitacion h
		ON r.id_habitacion = h.id
		LEFT JOIN cliente c
		ON c.id = r.id_cliente
	GROUP BY r.id, c.nombre,r.checkin, r.checkout, h.precio
) reserva_detalle
GROUP BY id_reserva, nombre, checkin, checkout;

-- Mostrando contenido de vista:
SELECT * FROM V_DETALLE_RESERVA;

-- Insertando datos sobre una vista:
INSERT INTO V_DETALLE_RESERVA 
	VALUES (101,'Alexandra','2010-01-20 15:00:00' ,'2010-01-21 13:00:00',190.85);

CREATE VIEW V_PAIS AS
SELECT * FROM PAIS;

INSERT INTO V_PAIS VALUES(33, 'Nueva Zelanda');
INSERT INTO PAIS VALUES (34, 'Egipto');
SELECT * FROM V_PAIS;
SELECT * FROM PAIS;

-- ¿Adonde se almacenan las vistas?
SELECT TABLE_NAME, VIEW_DEFINITION FROM INFORMATION_SCHEMA.views;

-- Borrando vista
DROP VIEW V_PAIS;
DROP VIEW V_DETALLE_RESERVA;

SELECT * FROM PAIS;
-- *****************************************************
-- 2.	Tablas temporales
-- *****************************************************
-- 2.1.	Crear una tabla temporal "#T_DETALLE_RESERVA" que muestre el detalle de cada reserva, la vista debe incluir
--		el id de la reserva, el nombre del cliente, la fecha de checkin y checkout
--		y el total de la reserva incluyendo el precio de la habitaciòn y los servicios.
SELECT id_reserva AS id, nombre AS nombre_cliente, checkin AS fecha_ini, checkout AS fecha_fin,  SUM(total_reserva) AS total_reserva
INTO #T_DETALLE_RESERVA
FROM (
	SELECT r.id id_reserva, c.nombre, r.checkin, r.checkout,  
				h.precio + ISNULL(SUM(s.precio), 0) AS total_reserva
	FROM reserva r LEFT JOIN extras x
			ON r.id = x.id_reserva
		LEFT JOIN servicio s
		ON x.id_servicio = s.id
		LEFT JOIN habitacion h
		ON r.id_habitacion = h.id
		LEFT JOIN cliente c
		ON c.id = r.id_cliente
	GROUP BY r.id, c.nombre,r.checkin, r.checkout, h.precio
) reserva_detalle
GROUP BY id_reserva, nombre, checkin, checkout;

--Mostrando contenido de tabla temporal:
SELECT * FROM #T_DETALLE_RESERVA;

--Insertando, actualizando y eliminando datos en tabla temporal:
INSERT INTO #T_DETALLE_RESERVA VALUES(101,'Susan','2010-01-01 15:00:00.000','2010-01-03 13:00:00.000',1000);

SELECT * FROM #T_DETALLE_RESERVA;
SELECT * FROM RESERVA;

--Insertando nueva reserva
EXEC BOOKING 101,'2010-01-20 15:00:00' ,'2010-01-21 13:00:00',9,4;

--Mostrando contenido de vista:
SELECT * FROM RESERVA;
SELECT * FROM #T_DETALLE_RESERVA;
