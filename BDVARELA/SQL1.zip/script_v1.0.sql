--****************************************************
-- Bases de datos: Introducci�n a SQL
-- Autor: Erick Varela
-- Correspondencia: evarela@uca.edu.sv
-- Version: 1.0
--****************************************************

-- Comentario de l�nea
/*
Comentario
de
bloque
*/

-- 1.0 CREANDO TABLAS.
-- 1.1 Creando tabla HOTEL
CREATE TABLE HOTEL (
	id INT, 
	nombre VARCHAR(50),
	direccion VARCHAR(50), 
	telefono CHAR(12)
);

-- 1.1.1 Mostrando la tabla
-- opci�n 1:
SELECT id, nombre, direccion, telefono FROM HOTEL;
-- opci�n 2:
SELECT * FROM HOTEL;
-- opci�n 3:
SELECT nombre, telefono FROM HOTEL;

-- 1.2 Insertando datos en tabla
	/*
	Id: 1
	Hotel: Real Intercontinental 
	Direcci�n: San Salvador
	Telefono: +50324234992
	*/
	
	/*
	Id: 2
	Hotel: Crowne Plaza
	Direcci�n: ---
	Telefono: +50325008446
	*/
	
	/*
	Id: ---
	Hotel: Quality Hotel Real Aeropuerto
	Direcci�n: ---
	Telefono: +50325008446
	*/

INSERT INTO HOTEL (id, nombre, direccion, telefono)
	VALUES (1, 'Real Intercontinental', 'San Salvador', '+50324234992');
INSERT INTO HOTEL (id, nombre, direccion, telefono)
	VALUES (2, 'Crowne Plaza', NULL,'+50325008446');
INSERT INTO HOTEL (nombre, telefono)
	VALUES ('Quality Hotel Real Aeropuerto', '+50325008446');
INSERT INTO HOTEL (id, nombre, direccion, telefono)
	VALUES (2, 'Crowne Plaza', NULL,'+50325008446');

-- mostrando datos
SELECT * FROM HOTEL;

-- 1.3 Mostrar toda la informaci�n de la tabla:
-- 1.1.1 Mostrando la tabla
-- opci�n 1:
SELECT id, nombre, direccion, telefono FROM HOTEL;
-- opci�n 2:
SELECT * FROM HOTEL;

-- 1.4 Mostrar algunas columnas:
SELECT nombre, telefono FROM HOTEL;

-- 1.5 El orden de seleccion de columnas no importa:
SELECT direccion, nombre, telefono, id FROM HOTEL;

-- 1.6 Borrando tabla
DROP TABLE HOTEL;

-- 2.0 RESTRICCIONES.
-- 2.1 Creando tabla HOTEL con columnas NULL (por defecto)/NOT NULL (Insertar hoteles 1,2 y 3)
CREATE TABLE HOTEL (
	id INT NULL, 
	nombre VARCHAR(50) NOT NULL,
	direccion VARCHAR(50) NULL, 
	telefono CHAR(12) NOT NULL
);

-- 2.2 Creando llave primaria
-- 2.2.1 A trav�s del comando ALTER
ALTER TABLE HOTEL ADD CONSTRAINT pk_hotel PRIMARY KEY (id); -- esto falla
-- Modificando tabla para poder configurar la llave primaria
ALTER TABLE HOTEL ALTER COLUMN id INT NOT NULL;
ALTER TABLE HOTEL ADD CONSTRAINT pk_hotel PRIMARY KEY (id); 
-- Insertando informaci�n
INSERT INTO HOTEL (id, nombre, direccion, telefono)
	VALUES (1, 'Real Intercontinental', 'San Salvador', '+50324234992');
INSERT INTO HOTEL (id, nombre, direccion, telefono)
	VALUES (2, 'Crowne Plaza', NULL,'+50325008446');
INSERT INTO HOTEL (nombre, direccion,telefono)
	VALUES ('Quality Hotel Real Aeropuerto','Direccion 123', '+50325008446');
INSERT INTO HOTEL (id, nombre, direccion, telefono)
	VALUES (2, 'Crowne Plaza', NULL,'+50325008446');
-- mostrando datos
SELECT * FROM HOTEL;
-- eliminando tabla:
DROP TABLE HOTEL;

-- 2.2.3 Definir llave primaria cuando se crea la tabla
CREATE TABLE HOTEL (
	id INT PRIMARY KEY, 
	nombre VARCHAR(50) NOT NULL,
	direccion VARCHAR(50) NULL, 
	telefono CHAR(12) NOT NULL
);

-- 2.2.4 Definir llave primaria al final de la definici�n de la tabla (Insertar hoteles 1,2 y 3)
CREATE TABLE HOTEL (
	id INT, 
	nombre VARCHAR(50) NOT NULL,
	direccion VARCHAR(50) NULL, 
	telefono CHAR(12) NOT NULL,
	CONSTRAINT pk_hotel PRIMARY KEY (id)
);
-- eliminando tabla:
DROP TABLE HOTEL;


	
	