--****************************************************
-- Bases de datos: Introducci�n a SQL II
-- Autor: Erick Varela
-- Correspondencia: evarela@uca.edu.sv
-- Version: 1.0
--****************************************************

-- Tabla base
/*
CREATE TABLE HOTEL (
	id INT PRIMARY KEY, 
	nombre VARCHAR(50) NOT NULL,
	direccion VARCHAR(50) NULL, 
	telefono CHAR(12) NOT NULL
);

INSERT INTO HOTEL (id, nombre, direccion, telefono)
	VALUES (1, 'Real Intercontinental', 'San Salvador', '+50324234992');
INSERT INTO HOTEL (id, nombre, direccion, telefono)
	VALUES (2, 'Crowne Plaza', NULL,'+50325008446');
INSERT INTO HOTEL (id, nombre, telefono)
	VALUES (3, 'Quality Hotel Real Aeropuerto', '+50325008446');
*/


-- 1.0 Columnas UNIQUE: definiendo la columna telefono como campo unico.
CREATE TABLE HOTEL (
	id INT PRIMARY KEY, 
	nombre VARCHAR(50) NOT NULL,
	direccion VARCHAR(50) NULL, 
	telefono CHAR(12) NOT NULL UNIQUE
);
-- primera opcion para modificar: DROP
DROP TABLE HOTEL; -- luego volver a ejecutar la tabla

-- 1.1 Insertando datos 
INSERT INTO HOTEL (id, nombre, direccion, telefono)
	VALUES (1, 'Real Intercontinental', 'San Salvador', '+50324234992');
INSERT INTO HOTEL (id, nombre, direccion, telefono)
	VALUES (2, 'Crowne Plaza', NULL,'+50325008446');
INSERT INTO HOTEL (id, nombre, telefono)
	VALUES (3, 'Quality Hotel Real Aeropuerto', '+50325008446'); --falla!!
INSERT INTO HOTEL (id, nombre, telefono)
	VALUES (3, 'Quality Hotel Real Aeropuerto', '+50325008445'); 
SELECT id, nombre, direccion, telefono FROM HOTEL;

-- 2.1 Borrar todos los datos de la tabla HOTEL
DELETE FROM HOTEL;
SELECT id, nombre, direccion, telefono FROM HOTEL;
-- 2.2 Borrar la tabla HOTEL
DROP TABLE HOTEL;

-- 3.0 Columnas Default: definiendo la columna direcci�n con un valor por defecto.
CREATE TABLE HOTEL (
	id INT PRIMARY KEY, 
	nombre VARCHAR(50) NOT NULL,
	direccion VARCHAR(50) NULL DEFAULT 'Direcci�n no definida', 
	telefono CHAR(12) NOT NULL UNIQUE
);

-- 3.1 Insertando datos 
INSERT INTO HOTEL (id, nombre, direccion, telefono)
	VALUES (1, 'Real Intercontinental', 'San Salvador', '+50324234992');
INSERT INTO HOTEL (id, nombre, direccion, telefono)
	VALUES (2, 'Crowne Plaza', NULL,'+50325008446');
INSERT INTO HOTEL (id, nombre, telefono)
	VALUES (3, 'Quality Hotel Real Aeropuerto', '+50325008445'); 
SELECT id, nombre, direccion, telefono FROM HOTEL;

-- 3.2 Borrar la tabla HOTEL
DROP TABLE HOTEL;

-- 4.0 Restricci�n CHECK
-- 4.1 Crear las tablas HOTEL y HABITACION con las siguientes restricciones:
--		- Campo telefono de HOTEL debe tener el formato:
--			- Debe incluir el identificador de pa�s +503
-- 			- El formato oficial de un telefono inicia con los digitos 2,6 y 7.
-- 			- El n�mero de telefono actual tiene 8 digitos de longitud.
--		- Campo numero de HABITACION debe tener el formato:
--			- numero mayor que 0
CREATE TABLE HABITACION(
	id INT PRIMARY KEY,
	numero INT NOT NULL CHECK (numero > 0),
	precio MONEY NOT NULL,
	id_hotel INT NULL
);

CREATE TABLE HOTEL (
	id INT PRIMARY KEY, 
	nombre VARCHAR(50) NOT NULL,
	direccion VARCHAR(50) NULL DEFAULT 'Direcci�n no definida', 
	telefono CHAR(12) NOT NULL UNIQUE CHECK (telefono LIKE '+503[2|6|7][0-9][0-9][0-9][0-9][0-9][0-9][0-9]')
);

-- Insertando datos
INSERT INTO HOTEL (id, nombre, direccion, telefono)
	VALUES (1, 'Real Intercontinental', 'San Salvador', '+50324234992');
INSERT INTO HOTEL (id, nombre, direccion, telefono)
	VALUES (2, 'Crowne Plaza', NULL,'+50325008446');
INSERT INTO HOTEL (id, nombre, telefono)
	VALUES (3, 'Quality Hotel Real Aeropuerto', '+50375008442'); 
SELECT id, nombre, direccion, telefono FROM HOTEL;

INSERT INTO HABITACION (id, numero, precio,id_hotel)
	VALUES (1, 1, 123.50, 1);
INSERT INTO HABITACION (id, numero, precio,id_hotel)
	VALUES (2, 2, 200.00, 1);
INSERT INTO HABITACION (id, numero, precio,id_hotel)
	VALUES (3, 5, 100.00, 35); -- No deber�a ser posible insertar esta informaci�n, porque no existe el hotel con id 35
INSERT INTO HABITACION (id, numero, precio,id_hotel)
	VALUES (4, 2, 322.45, NULL); -- No deber�a ser posible insertar esta informaci�n, por l�gica del negocio, no pueden exitir habitaciones sin ser asignadas a un hotel

SELECT * FROM HOTEL;
SELECT * FROM HABITACION;
-- 4.2 Borrar datos de las tablas HOTEL y HABITACION
DROP TABLE HOTEL;
DROP TABLE HABITACION;

-- 5.0 Definiendo restricciones de clave for�nea.
-- 5.1 Creando llave for�nea con campo "id_hotel" NULL
CREATE TABLE HOTEL (
	id INT PRIMARY KEY, 
	nombre VARCHAR(50) NOT NULL,
	direccion VARCHAR(50) NULL DEFAULT 'Direcci�n no definida', 
	telefono CHAR(12) NOT NULL UNIQUE CHECK (telefono LIKE '+503[2|6|7][0-9][0-9][0-9][0-9][0-9][0-9][0-9]')
);

CREATE TABLE HABITACION(
	id INT PRIMARY KEY,
	numero INT NOT NULL CHECK (numero > 0),
	precio MONEY NOT NULL,
	id_hotel INT NULL
);

-- Creando llave for�nea
ALTER TABLE HABITACION ADD FOREIGN KEY (id_hotel) REFERENCES HOTEL (id);

-- Intentando insertar bloques de informaci�n
INSERT INTO HOTEL (id, nombre, direccion, telefono)
	VALUES (1, 'Real Intercontinental', 'San Salvador', '+50324234992');
INSERT INTO HOTEL (id, nombre, direccion, telefono)
	VALUES (2, 'Crowne Plaza', NULL,'+50325008446');
INSERT INTO HOTEL (id, nombre, telefono)
	VALUES (3, 'Quality Hotel Real Aeropuerto', '+50375008442'); 
SELECT id, nombre, direccion, telefono FROM HOTEL;
INSERT INTO HABITACION (id, numero, precio,id_hotel)
	VALUES (1, 1, 123.50, 1);
INSERT INTO HABITACION (id, numero, precio,id_hotel)
	VALUES (2, 2, 200.00, 1);
INSERT INTO HABITACION (id, numero, precio,id_hotel)
	VALUES (3, 5, 100.00, 35); -- falla!!
-- corrigiendo error
INSERT INTO HABITACION (id, numero, precio,id_hotel)
	VALUES (3, 5, 100.00, 3);
INSERT INTO HABITACION (id, numero, precio,id_hotel)
	VALUES (4, 2, 322.45, NULL); -- No deber�a ser posible insertar esta informaci�n, por l�gica del negocio, no pueden exitir habitaciones sin ser asignadas a un hotel

SELECT * FROM HOTEL;
SELECT * FROM HABITACION;
-- 4.2 Borrar datos de las tablas HOTEL y HABITACION
DROP TABLE HOTEL;
DROP TABLE HABITACION;

-- 5.2 Definiendo llave for�nea como campo NOT NULL 
DROP TABLE HABITACION;
DROP TABLE HOTEL;

CREATE TABLE HOTEL (
	id INT PRIMARY KEY, 
	nombre VARCHAR(50) NOT NULL,
	direccion VARCHAR(50) NULL DEFAULT 'Direcci�n no definida', 
	telefono CHAR(12) NOT NULL UNIQUE CHECK (telefono LIKE '+503[2|6|7][0-9][0-9][0-9][0-9][0-9][0-9][0-9]')
);

CREATE TABLE HABITACION(
	id INT PRIMARY KEY,
	numero INT NOT NULL CHECK (numero > 0),
	precio MONEY NOT NULL,
	id_hotel INT NOT NULL
);

-- Creando llave for�nea
ALTER TABLE HABITACION ADD FOREIGN KEY (id_hotel) REFERENCES HOTEL (id);

/*
Opci�n alternativa para poder crear tabla y llaves for�neas simult�neamente
CREATE TABLE HABITACION(
	id INT PRIMARY KEY,
	numero INT NOT NULL CHECK (numero > 0),
	precio MONEY NOT NULL,
	id_hotel INT NOT NULL,
	CONSTRAINT fk_hotel FOREIGN KEY (id_hotel) REFERENCES HOTEL (id)
);
*/
-- Intentando insertar bloques de informaci�n
INSERT INTO HOTEL (id, nombre, direccion, telefono)
	VALUES (1, 'Real Intercontinental', 'San Salvador', '+50324234992');
INSERT INTO HOTEL (id, nombre, direccion, telefono)
	VALUES (2, 'Crowne Plaza', NULL,'+50325008446');
INSERT INTO HOTEL (id, nombre, telefono)
	VALUES (3, 'Quality Hotel Real Aeropuerto', '+50375008442'); 
SELECT id, nombre, direccion, telefono FROM HOTEL;

INSERT INTO HABITACION (id, numero, precio,id_hotel)
	VALUES (1, 1, 123.50, 1);
INSERT INTO HABITACION (id, numero, precio,id_hotel)
	VALUES (2, 2, 200.00, 1);
INSERT INTO HABITACION (id, numero, precio,id_hotel)
	VALUES (3, 5, 100.00, 35); -- falla!!
-- corrigiendo error
INSERT INTO HABITACION (id, numero, precio,id_hotel)
	VALUES (3, 5, 100.00, 3);
INSERT INTO HABITACION (id, numero, precio,id_hotel)
	VALUES (4, 2, 322.45, NULL); -- falla!!
-- corrigiendo error
INSERT INTO HABITACION (id, numero, precio,id_hotel)
	VALUES (4, 2, 322.45, 2);

SELECT * FROM HOTEL;
SELECT * FROM HABITACION;

-- 5.2.1. �Cuales son las implicaciones?

-- 5.3 Intentar eliminar un hotel
DELETE FROM HOTEL WHERE id = 1; -- falla porque existen referencias

-- 5.4 eliminar la restriccion y definir:
DROP TABLE HABITACION;
DROP TABLE HOTEL;

CREATE TABLE HOTEL (
	id INT PRIMARY KEY, 
	nombre VARCHAR(50) NOT NULL,
	direccion VARCHAR(50) NULL DEFAULT 'Direcci�n no definida', 
	telefono CHAR(12) NOT NULL UNIQUE CHECK (telefono LIKE '+503[2|6|7][0-9][0-9][0-9][0-9][0-9][0-9][0-9]')
);

CREATE TABLE HABITACION(
	id INT PRIMARY KEY,
	numero INT NOT NULL CHECK (numero > 0),
	precio MONEY NOT NULL,
	id_hotel INT NOT NULL
);

-- Creando llave for�nea
ALTER TABLE HABITACION ADD FOREIGN KEY (id_hotel) REFERENCES HOTEL (id) ON DELETE CASCADE;

-- Intentando insertar bloques de informaci�n
INSERT INTO HOTEL (id, nombre, direccion, telefono)
	VALUES (1, 'Real Intercontinental', 'San Salvador', '+50324234992');
INSERT INTO HOTEL (id, nombre, direccion, telefono)
	VALUES (2, 'Crowne Plaza', NULL,'+50325008446');
INSERT INTO HOTEL (id, nombre, telefono)
	VALUES (3, 'Quality Hotel Real Aeropuerto', '+50375008442'); 

INSERT INTO HABITACION (id, numero, precio,id_hotel)
	VALUES (1, 1, 123.50, 1);
INSERT INTO HABITACION (id, numero, precio,id_hotel)
	VALUES (2, 2, 200.00, 1);
INSERT INTO HABITACION (id, numero, precio,id_hotel)
	VALUES (3, 5, 100.00, 3);
INSERT INTO HABITACION (id, numero, precio,id_hotel)
	VALUES (4, 2, 322.45, 2);


SELECT * FROM HOTEL;
SELECT * FROM HABITACION;

-- 5.3 Intentar eliminar un hotel
DELETE FROM HOTEL WHERE id = 1; 

SELECT * FROM HOTEL;
SELECT * FROM HABITACION;
